"""
nexus_core/cloud_link.py — enlaza este Agent (Windows) con Nexus Cloud.

QUÉ HACE
    Convierte este PC en un dispositivo más de la cuenta del usuario en Nexus Cloud:

      Nexus Cloud ──(acción estructurada)──> CloudLink ──> ToolManager.run() ──> resultado
                                                                          │
      Nexus Cloud <──(executed | failed | awaiting_device)────────────────┘

    1. VINCULAR (una vez):  python -m nexus_core.cloud_link pair 7F4-K92
       El código lo genera el panel web (Dispositivos -> Vincular). Se guarda el
       device_id y un secreto de dispositivo en config/cloud_link.json.
    2. ESCUCHAR: un hilo hace SONDEO LARGO a /api/devices/pending-actions?wait=25.
       La petición queda abierta hasta que llega una acción (o pasan 25 s), así que
       una orden nueva llega en ~1-2 s. Cada llamada sirve también de latido.
    3. EJECUTAR: cada acción se traduce con nexus_core.actions_schema.to_tool_call()
       y se ejecuta con ToolManager.run() — el MISMO camino que las órdenes de voz,
       así que Security (niveles de riesgo) y el aviso de confirmación del HUD se
       aplican igual. Esto NO añade ninguna forma nueva de ejecutar nada.
    4. REPORTAR: un segundo hilo envía el resultado a /api/actions/report.

DISEÑO (lo que importa para no romper nada)
    * OPT-IN: si no se ha vinculado, VoiceEngine ni lo arranca.
    * Corre en hilos "daemon" propios. Ninguna excepción sale de ellos hacia el bucle
      de voz; ante fallos de red reintenta con espera creciente (2 s .. 60 s).
    * Solo biblioteca estándar (urllib): no añade dependencias.
    * Sin secretos en logs: los mensajes se construyen sin tocar el secreto.

LO QUE HAY QUE SABER (límites reales, no maquillados)
    * Una orden que necesita confirmación LOCAL (p. ej. apagar el equipo, que pasa
      por core.confirm) se reporta como 'awaiting_device' y, cuando alguien pulsa
      CONFIRMAR/CANCELAR en el HUD, se reporta el desenlace real gracias al
      observador core.confirm.set_outcome_hook. Si nadie pulsa, caduca a los ~100 s.
    * TAKE_SCREENSHOT no se anuncia ni se ejecuta por remoto: solo la sesión de voz
      en vivo puede ejecutar esa tool (es "inline") y aún no hay forma de subir la
      imagen. Falla con un motivo claro en vez de fingir.
    * ToolManager.run() devuelve TEXTO libre, no un código de estado. classify_result()
      distingue éxito/fallo con reglas sobre los textos conocidos; es una heurística
      y puede equivocarse con acciones que devuelvan mensajes de error inesperados.
    * Entrega "como mucho una vez": si el Agent se cae con una acción a medias, esa
      acción queda como 'delivered' en la nube y NO se repite sola.
"""
from __future__ import annotations

import argparse
import json
import os
import queue
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Optional

from nexus_core.actions_schema import Action, capabilities_for, to_tool_call

DEFAULT_CLOUD_URL = os.environ.get("NEXUS_CLOUD_URL", "https://nexus-cloud-estud-ia.vercel.app")
CONFIG_FILENAME = "cloud_link.json"

POLL_WAIT_S = 25            # debe ser <= al máximo que acepta el servidor (25)
HEARTBEAT_EVERY_S = 600
CONFIRM_TTL_S = 100         # core.confirm.TIMEOUT_SECONDS (90) + margen
MAX_RESULT_CHARS = 500


# ─────────────────────────── configuración local ───────────────────────────

def _default_config_path() -> Path:
    from memory.config_manager import get_base_dir
    return Path(get_base_dir()) / "config" / CONFIG_FILENAME


def load_config(path: Optional[Path] = None) -> dict:
    try:
        data = json.loads((path or _default_config_path()).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def save_config(cfg: dict, path: Optional[Path] = None) -> None:
    p = path or _default_config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    try:
        os.chmod(tmp, 0o600)  # en Windows no tiene efecto; en Linux/macOS evita que lo lean otros usuarios
    except OSError:
        pass
    os.replace(tmp, p)


# ─────────────────────────────── red ───────────────────────────────────────

class CloudError(Exception):
    def __init__(self, message: str, status: Optional[int] = None):
        super().__init__(message)
        self.status = status


class _Revoked(Exception):
    """El servidor dijo 401: las credenciales de este dispositivo ya no valen."""


def http_json(method: str, url: str, *, headers: Optional[dict] = None,
              body: Optional[dict] = None, timeout: float = 30) -> tuple[int, dict]:
    """Petición JSON. Devuelve (status, dict) también para 4xx/5xx; solo lanza
    CloudError si no hay conexión."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        url, data=data, method=method,
        headers={"Content-Type": "application/json", "Accept": "application/json", **(headers or {})},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw, status = resp.read(), resp.status
    except urllib.error.HTTPError as e:
        raw, status = e.read(), e.code
    except (urllib.error.URLError, OSError) as e:
        raise CloudError(f"sin conexión con Nexus Cloud: {e}") from e
    try:
        payload = json.loads(raw.decode("utf-8")) if raw else {}
    except ValueError:
        payload = {"error": raw[:200].decode("utf-8", "replace")}
    return status, payload if isinstance(payload, dict) else {}


# ───────────────────────────── vinculación ─────────────────────────────────

def pair(code: str, url: Optional[str] = None, *, config_path: Optional[Path] = None,
         http: Callable = http_json) -> dict:
    """Canjea el código del panel. Las capacidades reales se anuncian después, en
    el primer latido, cuando el Agent ya tiene su ToolManager cargado."""
    base = (url or DEFAULT_CLOUD_URL).rstrip("/")
    status, data = http("POST", f"{base}/api/devices/claim",
                        body={"pairing_code": code, "capabilities": []}, timeout=20)
    if status != 200 or "device_id" not in data or "device_secret" not in data:
        raise CloudError(str(data.get("error") or f"respuesta inesperada ({status})"), status)
    save_config({"url": base, "device_id": data["device_id"], "device_secret": data["device_secret"]}, config_path)
    return {"device_id": data["device_id"], "url": base}


# ─────────────────────── clasificación del resultado ───────────────────────

def classify_result(result: Optional[str]) -> str:
    """'awaiting_device' | 'failed' | 'executed' a partir del texto que devuelve
    ToolManager.run(). Heurística sobre los textos conocidos (ver docstring)."""
    text = (result or "").strip()
    if text.startswith("[CONFIRMATION_PENDING]"):
        return "awaiting_device"
    head = text[:120].lower()
    if text.startswith("Tool '") and ("failed" in head or "not available" in head):
        return "failed"
    if "is blocked by the current security policy" in head:
        return "failed"
    if text.startswith(("I cannot confirm", "Could not ask for confirmation")):
        return "failed"
    return "executed"


# ─────────────────────────────── el enlace ─────────────────────────────────

class CloudLink:
    def __init__(self, tools, *, ctx_factory: Optional[Callable[[], dict]] = None,
                 log: Optional[Callable[[str], None]] = None,
                 config_path: Optional[Path] = None,
                 http: Callable = http_json,
                 pause: Optional[Callable[[float], None]] = None,
                 poll_wait_s: int = POLL_WAIT_S, min_poll_gap_s: float = 5.0):
        self._tools = tools
        self._ctx_factory = ctx_factory or (lambda: {})
        self._log_cb = log
        self._http = http
        self._stop = threading.Event()
        self._pause_cb = pause
        self._poll_wait_s = poll_wait_s
        self._min_gap_s = min_poll_gap_s
        self._cfg = load_config(config_path)
        self._reports: "queue.Queue[tuple[str, str, str]]" = queue.Queue()
        self._awaiting: dict[str, dict] = {}
        self._awaiting_lock = threading.Lock()
        self._threads: list[threading.Thread] = []
        self._online: Optional[bool] = None
        self.disabled_reason: Optional[str] = None

    # -- estado ------------------------------------------------------------
    def is_configured(self) -> bool:
        return all(isinstance(self._cfg.get(k), str) and self._cfg[k]
                   for k in ("url", "device_id", "device_secret"))

    def _log(self, msg: str) -> None:
        if self._log_cb:
            try:
                self._log_cb(msg)
            except Exception:
                pass

    def _set_online(self, online: bool, detail: str = "") -> None:
        """Registra solo los CAMBIOS de estado, para no inundar el log si la red cae."""
        if online == self._online:
            return
        self._online = online
        self._log("SYS: Nexus Cloud conectado." if online else f"SYS: Nexus Cloud sin conexión ({detail}); reintentando.")

    def _headers(self) -> dict:
        return {"X-Device-Id": self._cfg["device_id"], "X-Device-Secret": self._cfg["device_secret"]}

    def _pause(self, seconds: float) -> None:
        if self._pause_cb:
            self._pause_cb(seconds)
        else:
            self._stop.wait(seconds)  # se despierta al instante si se llama a stop()

    # -- ciclo de vida -----------------------------------------------------
    def start(self) -> bool:
        if not self.is_configured() or self._threads:
            return False
        self._attach_confirm_hook()
        for target, name in ((self._poll_loop, "cloud-poll"), (self._report_loop, "cloud-report")):
            t = threading.Thread(target=target, name=name, daemon=True)
            t.start()
            self._threads.append(t)
        return True

    def stop(self) -> None:
        self._stop.set()
        try:
            from core import confirm as confirm_gate
            confirm_gate.set_outcome_hook(None)
        except Exception:
            pass

    def _attach_confirm_hook(self) -> None:
        try:
            from core import confirm as confirm_gate
            confirm_gate.set_outcome_hook(self._on_confirm_outcome)
        except Exception as e:
            self._log(f"ERR: no se pudo enganchar el observador de confirmaciones ({type(e).__name__}).")

    # -- hilo 1: sondeo largo + ejecución ----------------------------------
    def _heartbeat(self) -> None:
        try:
            caps = capabilities_for(self._tools, include_inline=False)["capabilities"]
            status, _ = self._http("POST", f"{self._cfg['url']}/api/devices/report",
                                   headers=self._headers(), body={"capabilities": caps}, timeout=20)
            if status == 401:
                raise _Revoked()
        except CloudError:
            pass  # el propio sondeo lo reintentará y avisará
        except _Revoked:
            raise
        except Exception as e:
            self._log(f"ERR: latido de Nexus Cloud falló ({type(e).__name__}).")

    def _poll_once(self) -> tuple[int, float]:
        t0 = time.monotonic()
        status, data = self._http(
            "GET", f"{self._cfg['url']}/api/devices/pending-actions?wait={self._poll_wait_s}",
            headers=self._headers(), timeout=self._poll_wait_s + 15)
        if status == 401:
            raise _Revoked()
        if status != 200:
            raise CloudError(str(data.get("error") or f"HTTP {status}"), status)
        actions = data.get("actions")
        actions = actions if isinstance(actions, list) else []
        for a in actions:
            if isinstance(a, dict):
                self._handle(a)
        return len(actions), time.monotonic() - t0

    def _poll_loop(self) -> None:
        backoff = 2.0
        # None = "todavía no se ha enviado ninguno". NO usar 0.0: time.monotonic() en
        # Windows cuenta desde el ARRANQUE del equipo, así que con el PC recién
        # encendido (<10 min) "monotonic() - 0.0 > 600" sería falso y el primer latido,
        # el que anuncia las capacidades, tardaría minutos en salir.
        last_heartbeat: Optional[float] = None
        while not self._stop.is_set():
            try:
                if last_heartbeat is None or time.monotonic() - last_heartbeat > HEARTBEAT_EVERY_S:
                    self._heartbeat()
                    last_heartbeat = time.monotonic()
                n, elapsed = self._poll_once()
                self._set_online(True)
                backoff = 2.0
                if n == 0 and elapsed < 1.0:
                    # Respuesta vacía e instantánea: un servidor sin sondeo largo. Sin este
                    # freno se le haría una petición en bucle sin descanso.
                    self._pause(self._min_gap_s)
            except _Revoked:
                self.disabled_reason = "el servidor rechazó las credenciales de este dispositivo"
                self._log("ERR: Nexus Cloud rechazó las credenciales de este PC (¿lo desvinculaste en el panel?). "
                          "Enlace desactivado; vuelve a vincular con `python -m nexus_core.cloud_link pair <código>`.")
                return
            except CloudError as e:
                self._set_online(False, str(e)[:120])
                self._pause(backoff)
                backoff = min(backoff * 2, 60.0)
            except Exception as e:  # el hilo NUNCA debe morir por un fallo inesperado
                self._log(f"ERR: fallo inesperado en el enlace con Nexus Cloud ({type(e).__name__}); reintentando.")
                self._pause(backoff)
                backoff = min(backoff * 2, 60.0)

    def _handle(self, a: dict) -> None:
        action_id = str(a.get("id") or "")
        if not action_id:
            return
        try:
            params = a.get("params")
            action = Action(action=str(a.get("action_type", "")), device_id=self._cfg["device_id"],
                            target=str(a.get("target") or ""), params=params if isinstance(params, dict) else {},
                            action_id=action_id)
            tool, tool_params, inline = to_tool_call(action)
        except ValueError as e:
            self._enqueue(action_id, "failed", str(e))
            return
        if inline:
            self._enqueue(action_id, "failed",
                          f"'{action.action}' no se puede ejecutar por control remoto en este Agent "
                          "(solo la sesión de voz en vivo puede hacerlo).")
            return

        self._log(f"SYS: Orden remota — {action.action} {action.target}".rstrip())
        try:
            result = self._tools.run(tool, tool_params, self._ctx_factory())
        except Exception as e:
            self._enqueue(action_id, "failed", f"{type(e).__name__}: {e}")
            return

        status = classify_result(result)
        if status == "awaiting_device":
            with self._awaiting_lock:
                self._awaiting[action_id] = {"tool": tool, "deadline": time.monotonic() + CONFIRM_TTL_S}
            self._enqueue(action_id, status, "Esperando confirmación en el PC: hay un aviso en la pantalla "
                                             f"(caduca en {CONFIRM_TTL_S - 10} s).")
        else:
            self._enqueue(action_id, status, result or "Hecho.")

    # -- desenlace de una confirmación local -------------------------------
    def _on_confirm_outcome(self, key: str, outcome: str, message: str) -> None:
        """Lo llama core.confirm desde el hilo de Qt o de trabajo: NO puede bloquear
        (una petición de red aquí congelaría la interfaz). Solo encola."""
        with self._awaiting_lock:
            action_id = next((aid for aid, info in self._awaiting.items() if info["tool"] == key), None)
            if action_id is None:
                return  # la confirmación no venía de una orden remota (p. ej. fue por voz)
            del self._awaiting[action_id]
        if outcome == "confirmed":
            self._enqueue(action_id, classify_result(message), message)
        elif outcome == "cancelled":
            self._enqueue(action_id, "failed", "Rechazada en el PC.")
        elif outcome == "expired":
            self._enqueue(action_id, "failed", "Caducó sin confirmar en el PC.")
        else:
            self._enqueue(action_id, "failed", message)

    def _expire_awaiting(self) -> None:
        now = time.monotonic()
        with self._awaiting_lock:
            expired = [aid for aid, info in self._awaiting.items() if info["deadline"] < now]
            for aid in expired:
                del self._awaiting[aid]
        for aid in expired:
            self._enqueue(aid, "failed", "Caducó sin confirmar en el PC.")

    # -- hilo 2: informar de resultados ------------------------------------
    def _enqueue(self, action_id: str, status: str, message: str) -> None:
        self._reports.put((action_id, status, (message or "")[:MAX_RESULT_CHARS]))

    def _report_loop(self) -> None:
        while not self._stop.is_set():
            self._expire_awaiting()
            try:
                item = self._reports.get(timeout=1.0)
            except queue.Empty:
                continue
            self._send_report(*item)

    def _send_report(self, action_id: str, status: str, message: str) -> None:
        delay = 1.0
        for attempt in range(5):
            try:
                code, data = self._http("POST", f"{self._cfg['url']}/api/actions/report",
                                        headers=self._headers(),
                                        body={"action_id": action_id, "status": status, "result": message}, timeout=20)
                if code == 200:
                    return
                if code in (401, 404):
                    # 404: la acción ya no admite resultado (p. ej. caducó); 401: credenciales revocadas.
                    self._log(f"ERR: Nexus Cloud no aceptó el resultado de una acción ({code}): {str(data.get('error', ''))[:120]}")
                    return
            except CloudError:
                pass
            except Exception as e:
                self._log(f"ERR: fallo al informar de un resultado ({type(e).__name__}).")
            self._pause(delay)
            delay = min(delay * 2, 30.0)
        self._log("ERR: no se pudo informar de un resultado a Nexus Cloud tras varios intentos; se descarta.")


# ──────────────────────────────── CLI ──────────────────────────────────────

def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m nexus_core.cloud_link",
                                 description="Vincula este PC con tu cuenta de Nexus Cloud.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p_pair = sub.add_parser("pair", help="canjear el código que genera el panel web")
    p_pair.add_argument("code", help="código de vinculación, p. ej. 7F4-K92")
    p_pair.add_argument("--url", help=f"URL de Nexus Cloud (por defecto {DEFAULT_CLOUD_URL})")
    sub.add_parser("status", help="ver si este PC está vinculado y si las credenciales valen")
    sub.add_parser("unpair", help="olvidar la vinculación en este PC")
    args = ap.parse_args(argv)

    if args.cmd == "pair":
        try:
            info = pair(args.code, args.url)
        except CloudError as e:
            print(f"No se pudo vincular: {e}", file=sys.stderr)
            return 1
        print(f"Vinculado. device_id: {info['device_id']}\nArranca NEXUS con `python main.py`: se conectará solo.")
        return 0

    cfg = load_config()
    if args.cmd == "unpair":
        try:
            _default_config_path().unlink()
            print("Vinculación local borrada. Para quitarlo también de tu cuenta, usa «Desvincular» en el panel web.")
        except FileNotFoundError:
            print("Este PC no estaba vinculado.")
        return 0

    # status
    if not all(cfg.get(k) for k in ("url", "device_id", "device_secret")):
        print("Este PC NO está vinculado. Usa: python -m nexus_core.cloud_link pair <código>")
        return 1
    print(f"Vinculado a {cfg['url']}\ndevice_id: {cfg['device_id']}\nsecreto: guardado (no se muestra)")
    try:
        # Un latido: comprueba las credenciales SIN reclamar ninguna acción pendiente.
        code, data = http_json("POST", f"{cfg['url']}/api/devices/report",
                               headers={"X-Device-Id": cfg["device_id"], "X-Device-Secret": cfg["device_secret"]},
                               body={}, timeout=20)
    except CloudError as e:
        print(f"No se pudo comprobar: {e}")
        return 2
    print("Credenciales válidas: Nexus Cloud te ve online." if code == 200
          else f"Nexus Cloud rechaza este dispositivo ({code}): {data.get('error', '')}")
    return 0 if code == 200 else 1


if __name__ == "__main__":
    raise SystemExit(main())
