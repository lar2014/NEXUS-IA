# CLOUD_LINK.md — Conectar este PC (Agent de Windows) con Nexus Cloud

Módulo: `nexus_core/cloud_link.py`. Es **opt-in**: si no vinculas el PC, NEXUS
funciona exactamente como antes.

## Usarlo

```bash
# 1) En el panel web: Dispositivos -> "Vincular un dispositivo nuevo" (tipo PC) -> copia el código
python -m nexus_core.cloud_link pair 7F4-K92

# 2) Arranca NEXUS como siempre; se conecta solo
python main.py

# Otros comandos
python -m nexus_core.cloud_link status     # ¿está vinculado? ¿valen las credenciales?
python -m nexus_core.cloud_link unpair     # olvidar la vinculación en este PC
```
Después, en el panel: «abre Chrome en mi PC» → se ejecuta aquí en ~1-2 segundos.

## Qué pasa por dentro

```
Panel/IA ──> Nexus Cloud (cola de acciones) <──sondeo largo──> CloudLink ──> ToolManager.run() ──> tool
                                                                   │                                  │
                                                                   └──── executed / failed / awaiting_device ◄──┘
```
- **Sondeo largo**: pide `GET /api/devices/pending-actions?wait=25`. El servidor
  mantiene la petición abierta hasta que hay una acción o pasan 25 s. Por eso una
  orden llega en ~1-2 s sin que el PC tenga que abrir ningún puerto.
- **Mismas barreras que la voz**: se ejecuta con `ToolManager.run()`, el mismo
  camino que las órdenes por voz. Los niveles de riesgo de `security.py` y el aviso
  de confirmación del HUD se aplican igual. No hay ninguna forma nueva de ejecutar.
- **Confirmación doble para lo peligroso**: apagar el PC pide aprobación en el panel
  (política por defecto de Nexus Cloud) **y** después el aviso del HUD de este PC
  (`core.confirm`). El desenlace real (confirmado / rechazado / caducado) se
  reporta a la nube gracias a un observador opcional que añadí a `core/confirm.py`
  (sin observador, `confirm.py` se comporta exactamente como antes).
- **Hilos propios** (daemon): nada de lo que falle aquí puede llegar al bucle de voz.
  Sin red, reintenta con espera creciente de 2 a 60 s y avisa solo del cambio de estado.

## Límites reales

| Límite | Detalle |
|---|---|
| `TAKE_SCREENSHOT` remoto | No se anuncia ni se ejecuta: solo la sesión de voz en vivo puede lanzar esa tool y aún no hay forma de subir la imagen. |
| Resultado = texto libre | `ToolManager.run()` devuelve texto, no un código. `classify_result()` reconoce los textos de error conocidos; un fallo con un texto inesperado se reportaría como «ejecutada». |
| Una vez como mucho | Si NEXUS se cierra con una acción a medias, queda como «entregada» en la nube y **no se repite sola** (evita mandar dos veces un mensaje). |
| Caducidad | Una acción que espera más de 1 hora (sin recoger o sin aprobar) se descarta. |
| Confirmación local sin nadie | Si el aviso del HUD no se pulsa, caduca a los ~100 s y se reporta como fallida. |
| Secreto en claro | `config/cloud_link.json` guarda el secreto del dispositivo sin cifrar (como `api_keys.json`); ya está en `.gitignore`. Quien lo copie puede enviar órdenes a este PC **dentro de los permisos que tengas puestos**. Si se filtra: «Desvincular» en el panel lo invalida al instante. |

## Lo que NO he podido comprobar aquí

El arranque desde `VoiceEngine.run()` (14 líneas dentro de un `try/except`) no se ha
ejecutado: exige PyQt6, audio y Gemini. Todo lo demás se ha probado contra un
servidor HTTP real en local y contra el `core.confirm` real
(`python -m unittest discover -s tests -v`, 23 pruebas).
