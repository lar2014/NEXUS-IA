// Prueba del panel web en un navegador simulado (jsdom) con el servidor falseado.
// Ejecutar:  npm install --no-save jsdom && node tests-ui/panel.test.js
const { JSDOM } = require("jsdom");
const fs = require("fs");
const root = require("path").join(__dirname, "..", "public") + "/";
const html = fs.readFileSync(root + "index.html", "utf8").replace(/<script[^>]*><\/script>/, "");
const js = fs.readFileSync(root + "app.js", "utf8");

const SB = "https://proj.supabase.co";
const now = new Date().toISOString();
const calls = [];
let devicesData = [
  { id: "d1", name: "Mi Android", type: "android", capabilities: ["OPEN_APP", "SET_VOLUME"], permissions: { SET_VOLUME: "REQUIERE_CONFIRMACION" }, connected: true, last_seen: now, linked_at: now, pairing_expires_at: null, online: true },
  { id: "d2", name: "Portátil nuevo", type: "pc", capabilities: [], permissions: {}, connected: false, last_seen: null, linked_at: now, pairing_expires_at: new Date(Date.now() + 300000).toISOString(), online: false },
];
let providersData = [{ id: "11111111-1111-1111-1111-111111111111", provider: "gemini", label: "", model: null, is_default: true, created_at: now }];
let actionsData = [
  { id: "a1", device_id: "d1", action_type: "SET_VOLUME", target: "30", status: "awaiting_confirmation", result: null, created_at: now },
  { id: "a2", device_id: "d1", action_type: "OPEN_APP", target: "<img src=x onerror=alert(1)>", status: "executed", result: "Abierta: com.whatsapp", created_at: now },
];
const resp = (status, obj) => ({ ok: status < 400, status, text: async () => JSON.stringify(obj), json: async () => obj });

async function fakeFetch(url, opts = {}) {
  const method = (opts.method || "GET").toUpperCase();
  calls.push({ url, method, body: opts.body ? JSON.parse(opts.body) : null, auth: opts.headers && opts.headers.Authorization });
  if (url === "/api/config") return resp(200, { supabaseUrl: SB, supabaseAnonKey: "sb_publishable_x", actionTypes: ["OPEN_APP", "OPEN_URL", "SET_VOLUME"],
    defaultPermissions: { OPEN_APP: "PERMITIDO", OPEN_URL: "PERMITIDO", SET_VOLUME: "PERMITIDO" },
    providerDefaults: { gemini: "gemini-2.5-flash", anthropic: "claude-haiku-4-5-20251001", openai: "gpt-4o-mini", openrouter: null } });
  if (url.startsWith(SB + "/auth/v1/token?grant_type=password")) {
    const b = JSON.parse(opts.body);
    if (b.password === "mala") return resp(400, { error_description: "Invalid login credentials" });
    return resp(200, { access_token: "AT", refresh_token: "RT", expires_in: 3600, user: { email: b.email } });
  }
  if (url === SB + "/auth/v1/logout") return resp(204, {});
  if (url === "/api/devices" && method === "GET") return resp(200, { devices: devicesData });
  if (url === "/api/actions" && method === "GET") return resp(200, { actions: actionsData });
  if (url === "/api/providers" && method === "GET") return resp(200, { providers: providersData });
  if (url.startsWith("/api/providers?id=") && method === "DELETE") { providersData = []; return resp(200, { ok: true }); }
  if (url === "/api/command") {
    const b = JSON.parse(opts.body);
    if (b.message === "sin clave") return resp(409, { error: "Guarda primero una clave de IA", code: "no_provider" });
    return resp(200, { reply: "Abriendo <b>WhatsApp</b> en tu móvil.", clarification: null, provider: "gemini", model: "gemini-2.5-flash", warnings: ["una acción descartada"],
      actions: [ { action: "OPEN_APP", device_id: "d1", device_name: "Mi Android", target: "whatsapp", status: "pending" },
                 { action: "SHUTDOWN_DEVICE", device_id: "d1", device_name: "Mi Android", target: "", error: "no soporta SHUTDOWN_DEVICE", http_status: 422 } ] });
  }
  if (url === "/api/devices/pairing") return resp(201, { device_id: "d3", pairing_code: "7F4-K92", expires_at: new Date(Date.now() + 600000).toISOString() });
  if (url === "/api/actions" && method === "POST") return resp(202, { action_log: { status: "pending" }, delivered: false });
  if (url === "/api/actions/confirm") { actionsData = actionsData.map((a) => a.id === "a1" ? { ...a, status: "pending" } : a); return resp(200, { ok: true, status: "pending" }); }
  if (url === "/api/providers" && method === "POST") return resp(201, { provider_config_id: "p1" });
  return resp(404, { error: "no mock para " + method + " " + url });
}

const tick = (ms = 30) => new Promise((r) => setTimeout(r, ms));
let failures = 0;
const check = (name, cond) => { console.log((cond ? "  OK   " : "  FALLA ") + name); if (!cond) failures++; };

(async () => {
  const dom = new JSDOM(html, { url: "https://nexus.test/", runScripts: "outside-only", pretendToBeVisual: true });
  const w = dom.window;
  w.fetch = fakeFetch;
  const errors = [];
  w.addEventListener("error", (e) => errors.push(e.message));
  w.eval(js);
  await tick(60);
  const $ = (s) => w.document.querySelector(s);
  const submit = (form) => form.dispatchEvent(new w.Event("submit", { cancelable: true, bubbles: true }));

  console.log("1) Sin sesión guardada");
  check("se muestra la pantalla de login", !$("#auth-view").hidden && $("#main-view").hidden);
  check("el select de acciones se rellenó desde /api/config", $("#action-type").options.length === 3);

  console.log("2) Login con contraseña incorrecta");
  $("#email").value = "angel@ejemplo.com"; $("#password").value = "mala";
  submit($("#auth-form")); await tick();
  check("muestra el error traducido", $("#toast").textContent === "Correo o contraseña incorrectos.");
  check("sigue en la pantalla de login", !$("#auth-view").hidden);

  console.log("3) Login correcto");
  $("#password").value = "buena-clave-123";
  submit($("#auth-form")); await tick(80);
  check("entra al panel", $("#auth-view").hidden && !$("#main-view").hidden);
  check("muestra el correo", $("#user-email").textContent === "angel@ejemplo.com");
  check("guarda la sesión en localStorage", !!w.localStorage.getItem("nexus_session"));
  check("las llamadas a la API llevan el Bearer", calls.filter((c) => c.url.startsWith("/api/") && c.url !== "/api/config").every((c) => c.auth === "Bearer AT"));
  check("la contraseña se borró del campo", $("#password").value === "");

  console.log("4) Dispositivos");
  const devText = $("#devices").textContent;
  check("lista el Android como Online", devText.includes("Mi Android") && devText.includes("Online"));
  check("el portátil aparece pendiente de vincular", devText.includes("Pendiente de vincular"));
  check("el desplegable de acciones solo ofrece dispositivos ya vinculados", $("#action-device").options.length === 1 && $("#action-device").value === "d1");
  check("hay un select de permisos por cada tipo de acción (3 x 2 dispositivos)", w.document.querySelectorAll("#devices .perm-row select").length === 6);
  check("el permiso guardado aparece preseleccionado", w.document.querySelector('#devices select[data-action="SET_VOLUME"]').value === "REQUIERE_CONFIRMACION");

  console.log("5) Acciones y XSS");
  check("lista las 2 acciones", w.document.querySelectorAll("#actions .action").length === 2);
  check("la acción pendiente de confirmar tiene botón Aprobar", [...w.document.querySelectorAll("#actions button")].some((b) => b.textContent === "Aprobar"));
  check("un target malicioso se muestra como TEXTO, no como HTML", w.document.querySelectorAll("#actions img").length === 0 && $("#actions").textContent.includes("<img src=x onerror=alert(1)>"));

  console.log("6) Aprobar una acción");
  [...w.document.querySelectorAll("#actions button")].find((b) => b.textContent === "Aprobar").click();
  await tick(60);
  const confirmCall = calls.find((c) => c.url === "/api/actions/confirm");
  check("llama a /api/actions/confirm con approve=true", confirmCall && confirmCall.body.action_id === "a1" && confirmCall.body.approve === true);
  check("tras aprobar ya no hay botón Aprobar", ![...w.document.querySelectorAll("#actions button")].some((b) => b.textContent === "Aprobar"));

  console.log("7) Vincular dispositivo");
  $("#pair-name").value = "Mi tablet"; $("#pair-type").value = "android";
  submit($("#pair-form")); await tick(60);
  check("muestra el código 7F4-K92", !$("#pair-result").hidden && $("#pair-result").textContent.includes("7F4-K92"));

  console.log("8) Enviar acción");
  $("#action-type").value = "OPEN_APP"; $("#action-target").value = "whatsapp";
  submit($("#action-form")); await tick(60);
  const sent = calls.find((c) => c.url === "/api/actions" && c.method === "POST");
  check("POST /api/actions con la forma correcta", sent && sent.body.action === "OPEN_APP" && sent.body.device_id === "d1" && sent.body.target === "whatsapp");
  check("explica que queda en cola", $("#action-result").textContent.startsWith("En cola"));

  console.log("9) Guardar clave de proveedor");
  $("#provider-name").value = "anthropic"; $("#provider-key").value = "sk-secreta";
  submit($("#provider-form")); await tick(60);
  const provCall = calls.find((c) => c.url === "/api/providers" && c.method === "POST");
  check("envía la clave al servidor", provCall && provCall.body.api_key === "sk-secreta" && provCall.body.provider === "anthropic");
  check("la clave se borra del campo tras enviarla", $("#provider-key").value === "");

  console.log("9b) Etiquetas de permisos por defecto");
  const optText = (a, d) => w.document.querySelector(`#devices .device:nth-child(${d}) select[data-action="${a}"] option`).textContent;
  check("la primera opción enseña la política por defecto real de la acción", optText("OPEN_APP", 1) === "Por defecto (Permitido)");

  console.log("9c) Proveedores: modelo y borrado");
  const provText = $("#providers").textContent;
  check("lista la clave con su modelo por defecto y 'En uso'", provText.includes("gemini-2.5-flash") && provText.includes("En uso"));
  check("OpenRouter exige modelo (campo obligatorio) y Gemini no", (() => { $("#provider-name").value = "openrouter"; $("#provider-name").dispatchEvent(new w.Event("change")); const r = $("#provider-model").required; $("#provider-name").value = "gemini"; $("#provider-name").dispatchEvent(new w.Event("change")); return r && !$("#provider-model").required; })());
  w.confirm = () => true;
  [...w.document.querySelectorAll("#providers button")].find((b) => b.textContent === "Eliminar").click();
  await tick(60);
  check("Eliminar llama a DELETE /api/providers?id=…", calls.some((c) => c.method === "DELETE" && c.url.startsWith("/api/providers?id=1111")));
  check("tras borrar, la lista queda vacía", $("#providers").textContent.includes("No has guardado ninguna clave"));

  console.log("9d) Hablar con Nexus");
  const before = calls.filter((c) => c.url === "/api/actions" && c.method === "GET").length;
  $("#command-input").value = "abre whatsapp en mi móvil";
  submit($("#command-form")); await tick(80);
  const cc = calls.find((c) => c.url === "/api/command");
  check("envía POST /api/command con el mensaje", cc && cc.method === "POST" && cc.body.message === "abre whatsapp en mi móvil");
  const cr = $("#command-result");
  check("muestra la respuesta, la acción creada y la acción rechazada con su motivo", !cr.hidden && cr.textContent.includes("OPEN_APP → whatsapp") && cr.textContent.includes("no soporta SHUTDOWN_DEVICE"));
  check("marca 'En cola' y 'No creada'", cr.textContent.includes("En cola") && cr.textContent.includes("No creada"));
  check("XSS: el HTML de la respuesta de la IA se ve como texto", cr.querySelectorAll("b").length === 0 && cr.textContent.includes("<b>WhatsApp</b>"));
  check("indica con qué proveedor y modelo se interpretó", cr.textContent.includes("gemini-2.5-flash"));
  check("vacía el campo y refresca las acciones", $("#command-input").value === "" && calls.filter((c) => c.url === "/api/actions" && c.method === "GET").length > before);
  $("#command-input").value = "sin clave";
  submit($("#command-form")); await tick(60);
  check("si no hay clave de IA, avisa con el motivo y oculta el resultado", $("#toast").textContent.includes("Guarda primero una clave") && $("#command-result").hidden);

  console.log("10) Recarga con sesión guardada + salir");
  const saved = w.localStorage.getItem("nexus_session");
  const dom2 = new JSDOM(html, { url: "https://nexus.test/", runScripts: "outside-only", pretendToBeVisual: true });
  dom2.window.fetch = fakeFetch; dom2.window.localStorage.setItem("nexus_session", saved);
  dom2.window.eval(js); await tick(100);
  check("entra directamente al panel sin pedir login", !dom2.window.document.querySelector("#main-view").hidden);
  dom2.window.document.querySelector("#logout").click(); await tick(40);
  check("salir vuelve al login y borra la sesión", !dom2.window.document.querySelector("#auth-view").hidden && dom2.window.localStorage.getItem("nexus_session") === null);

  check("ningún error JS no capturado", errors.length === 0);
  console.log(failures ? `\n${failures} FALLO(S)` : "\nTODO OK");
  process.exit(failures ? 1 : 0);
})();
