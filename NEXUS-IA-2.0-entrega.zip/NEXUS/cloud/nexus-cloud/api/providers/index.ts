import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedUser } from "../../src/lib/auth";
import { supabaseForUser } from "../../src/lib/supabaseForUser";
import { PROVIDER_DEFAULT_MODELS } from "../../src/lib/providers";

// "custom" existe en el esquema pero no se acepta todavía: haría falta guardar su URL base.
const PROVIDERS = Object.keys(PROVIDER_DEFAULT_MODELS);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const user = await getAuthedUser(req);
  if (!user) return res.status(401).json({ error: "no autenticado" });
  const db = supabaseForUser(user.accessToken);

  if (req.method === "GET") {
    // Nunca se selecciona api_key_vault_id: ni la referencia al secreto sale hacia el navegador.
    const { data, error } = await db.from("provider_configs").select("id, provider, label, model, is_default, created_at").order("created_at", { ascending: false });
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ providers: data });
  }

  if (req.method === "POST") {
    const { provider, label, api_key, model } = (req.body ?? {}) as { provider?: unknown; label?: unknown; api_key?: unknown; model?: unknown };
    if (typeof provider !== "string" || !PROVIDERS.includes(provider)) {
      return res.status(400).json({ error: `provider debe ser uno de: ${PROVIDERS.join(", ")}` });
    }
    if (typeof api_key !== "string" || !api_key.trim()) return res.status(400).json({ error: "api_key es obligatoria" });
    const cleanModel = typeof model === "string" ? model.trim().slice(0, 100) : "";
    if (!cleanModel && PROVIDER_DEFAULT_MODELS[provider] === null) {
      return res.status(400).json({ error: `para ${provider} tienes que indicar el modelo (p. ej. anthropic/claude-haiku-4.5)` });
    }

    // create_provider_secret cifra la clave en Supabase Vault y devuelve solo el id de la fila.
    const { data: configId, error } = await db.rpc("create_provider_secret", {
      p_provider: provider,
      p_label: typeof label === "string" ? label.trim().slice(0, 60) : "",
      p_api_key: api_key.trim(),
    });
    if (error) return res.status(500).json({ error: error.message });

    const warnings: string[] = [];
    if (cleanModel) {
      const { error: mErr } = await db.from("provider_configs").update({ model: cleanModel }).eq("id", configId);
      if (mErr) warnings.push("la clave se guardó, pero no se pudo guardar el modelo");
    }
    // La primera clave que guarda el usuario pasa a ser la que usa el cerebro.
    const { data: existing } = await db.from("provider_configs").select("id").eq("is_default", true).limit(1);
    if (!existing?.length) await db.from("provider_configs").update({ is_default: true }).eq("id", configId);

    return res.status(201).json({ provider_config_id: configId, warnings });
  }

  if (req.method === "DELETE") {
    const id = req.query.id;
    if (typeof id !== "string" || !UUID.test(id)) return res.status(400).json({ error: "id inválido" });
    // Borra la fila Y el secreto cifrado del Vault (función SQL, comprueba que sea tuya).
    const { data, error } = await db.rpc("delete_provider_config", { p_config_id: id });
    if (error) return res.status(500).json({ error: error.message });
    if (!data) return res.status(404).json({ error: "clave no encontrada o no es tuya" });
    return res.status(200).json({ ok: true });
  }

  res.setHeader("Allow", "GET, POST, DELETE");
  return res.status(405).json({ error: "método no permitido" });
}
