import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedUser } from "../src/lib/auth";
import { supabaseAdmin } from "../src/lib/supabaseAdmin";
import { supabaseForUser } from "../src/lib/supabaseForUser";
import { runCommand } from "../src/lib/commandService";

/**
 * POST { message, provider_id? } — "abre WhatsApp en mi móvil".
 * Toda la lógica está en src/lib/commandService.ts (probada de forma aislada);
 * esto solo cablea autenticación, cliente y lectura de la clave.
 * NO se registra ni se guarda el texto del mensaje ni la clave.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "método no permitido" });
  }
  const user = await getAuthedUser(req);
  if (!user) return res.status(401).json({ error: "no autenticado" });

  const body = (req.body ?? {}) as { message?: unknown; provider_id?: unknown };
  try {
    const out = await runCommand(
      {
        db: supabaseForUser(user.accessToken),
        userId: user.userId,
        // La función SQL comprueba ELLA MISMA que la clave es de este usuario.
        getProviderKey: async (configId) => {
          const { data, error } = await supabaseAdmin().rpc("get_provider_secret", { p_config_id: configId, p_user_id: user.userId });
          if (error) throw new Error("no se pudo leer la clave");
          return data;
        },
      },
      { message: body.message, providerId: body.provider_id },
    );
    return res.status(out.status).json(out.body);
  } catch {
    return res.status(500).json({ error: "error inesperado al procesar la orden", code: "internal" });
  }
}
