import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedDevice } from "../../src/lib/deviceAuth";
import { supabaseAdmin } from "../../src/lib/supabaseAdmin";
import type { TablesUpdate, Json } from "../../src/lib/database.types";

/**
 * El Agent llama a esto periódicamente (p. ej. cada vez que arranca, y cada
 * pocos minutos mientras sigue vivo) para marcarse "connected: true" y
 * refrescar last_seen. No hay una desconexión explícita — igual que el
 * Agent local (dashboard/server.py) infiere "desconectado" por ausencia de
 * latido, no por un aviso expreso.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "método no permitido" });
  }

  const device = await getAuthedDevice(req);
  if (!device) return res.status(401).json({ error: "dispositivo no autenticado" });

  const { capabilities } = (req.body ?? {}) as { capabilities?: string[] };
  const update: TablesUpdate<"devices"> = {
    connected: true,
    last_seen: new Date().toISOString(),
  };
  if (Array.isArray(capabilities)) update.capabilities = capabilities as Json;

  const { error } = await supabaseAdmin().from("devices").update(update).eq("id", device.deviceId);
  if (error) return res.status(500).json({ error: error.message });

  return res.status(200).json({ ok: true });
}
