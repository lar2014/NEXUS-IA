import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedUser } from "../../src/lib/auth";
import { supabaseForUser } from "../../src/lib/supabaseForUser";
import { isOnline } from "../../src/lib/presence";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const user = await getAuthedUser(req);
  if (!user) return res.status(401).json({ error: "no autenticado" });

  if (req.method === "GET") {
    // supabaseForUser reenvía el JWT: RLS garantiza que solo salen los dispositivos de ESTE usuario.
    const { data, error } = await supabaseForUser(user.accessToken)
      .from("devices")
      .select("id, name, type, capabilities, permissions, connected, last_seen, linked_at, pairing_expires_at")
      .order("linked_at", { ascending: false });
    if (error) return res.status(500).json({ error: error.message });

    // 'connected' solo lo pone a true un latido y nada lo baja: el estado real se deduce del último latido.
    const now = Date.now();
    return res.status(200).json({ devices: (data ?? []).map((d) => ({ ...d, online: isOnline(d, now) })) });
  }

  res.setHeader("Allow", "GET");
  return res.status(405).json({ error: "método no permitido" });
}
