import type { VercelRequest, VercelResponse } from "@vercel/node";
import crypto from "node:crypto";
import { supabaseAdmin } from "../../src/lib/supabaseAdmin";

/** Acepta "abc-123", "ABC123", " abc 123 "... y lo deja como "ABC-123". */
function normalizePairingCode(raw: string): string {
  const compact = raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
  return compact.length === 6 ? `${compact.slice(0, 3)}-${compact.slice(3)}` : raw.trim().toUpperCase();
}

/**
 * Lo llama el AGENT, no el usuario — todavía no tiene sesión, solo el código
 * que el usuario le mostró (generado por pairing.ts). Por eso usa
 * supabaseAdmin() (bypassa RLS): es la única ruta donde está justificado, y
 * solo puede tocar la fila cuyo pairing_code coincide y no ha caducado.
 *
 * La reclamación es UNA sola sentencia atómica (UPDATE ... WHERE código = X
 * AND no caducado). Antes eran dos pasos (leer, luego escribir): dos
 * reclamaciones simultáneas del mismo código podían pisarse el secreto.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "método no permitido" });
  }

  const { pairing_code, capabilities } = (req.body ?? {}) as {
    pairing_code?: unknown;
    capabilities?: unknown;
  };
  if (typeof pairing_code !== "string" || !pairing_code.trim()) {
    return res.status(400).json({ error: "pairing_code es obligatorio" });
  }
  const code = normalizePairingCode(pairing_code);
  const caps = Array.isArray(capabilities)
    ? capabilities.filter((c): c is string => typeof c === "string")
    : [];

  const deviceSecret = crypto.randomBytes(32).toString("base64url");
  const secretHash = crypto.createHash("sha256").update(deviceSecret).digest("hex");

  const admin = supabaseAdmin();
  const { data: claimed, error: updateError } = await admin
    .from("devices")
    .update({
      connected: true,
      last_seen: new Date().toISOString(),
      capabilities: caps,
      pairing_code: null,
      pairing_expires_at: null,
      device_secret_hash: secretHash,
    })
    .eq("pairing_code", code)
    .gt("pairing_expires_at", new Date().toISOString())
    .select("id")
    .maybeSingle();

  if (updateError) return res.status(500).json({ error: updateError.message });

  if (!claimed) {
    // Nada actualizado: o el código no existe, o existe pero caducó.
    const { data: stale } = await admin
      .from("devices")
      .select("id")
      .eq("pairing_code", code)
      .maybeSingle();
    return stale
      ? res.status(410).json({ error: "código de vinculación caducado" })
      : res.status(404).json({ error: "código de vinculación inválido" });
  }

  // El secreto en claro se devuelve UNA sola vez, aquí. Nexus Cloud solo
  // conserva su hash.
  return res.status(200).json({ device_id: claimed.id, device_secret: deviceSecret });
}
