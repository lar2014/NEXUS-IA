import type { VercelRequest, VercelResponse } from "@vercel/node";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "../../src/lib/database.types";
import { getAuthedDevice } from "../../src/lib/deviceAuth";
import { supabaseAdmin } from "../../src/lib/supabaseAdmin";
import { ACTION_TTL_MS } from "../../src/lib/permissions";

const MAX_WAIT_S = 25;       // por debajo del límite de la función (30 s)
const POLL_EVERY_MS = 1500;  // consulta a la base de datos mientras espera

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/**
 * Reclama las acciones pendientes del dispositivo. Es un UPDATE condicionado a
 * status='pending' que DEVUELVE solo las filas que de verdad pasó a 'delivered':
 * dos sondeos simultáneos nunca reciben la misma acción, y una acción entregada
 * no se reentrega sola (semántica "como mucho una vez": si el Agent cae a
 * medias queda visible como entregada sin resultado, no se repite a ciegas).
 */
async function claimPending(admin: SupabaseClient<Database>, deviceId: string) {
  const { data: ids, error } = await admin
    .from("actions_log").select("id").eq("device_id", deviceId).eq("status", "pending")
    .order("created_at", { ascending: true }).limit(20);
  if (error) throw new Error(error.message);
  if (!ids?.length) return [];

  const { data, error: updateError } = await admin
    .from("actions_log")
    .update({ status: "delivered", delivered_at: new Date().toISOString() })
    .in("id", ids.map((r) => r.id))
    .eq("status", "pending")
    .select("id, action_type, target, params, created_at");
  if (updateError) throw new Error(updateError.message);
  return (data ?? []).sort((a, b) => (a.created_at < b.created_at ? -1 : 1));
}

/**
 * GET /api/devices/pending-actions[?wait=N]
 *   sin wait (o 0): responde ya (lo usa el Agent Android, que solo puede sondear a ratos)
 *   wait=N (máx. 25): SONDEO LARGO — la petición espera hasta que llegue una acción o
 *   pasen N segundos. Con el Agent en bucle, una acción nueva llega en ~1-2 s en vez de
 *   esperar a un sondeo periódico. Sirve como latido: cada llamada refresca last_seen.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "método no permitido" });
  }
  const device = await getAuthedDevice(req);
  if (!device) return res.status(401).json({ error: "dispositivo no autenticado" });

  const parsed = Number.parseInt(String(req.query.wait ?? "0"), 10);
  const waitS = Number.isFinite(parsed) ? Math.min(Math.max(parsed, 0), MAX_WAIT_S) : 0;
  const admin = supabaseAdmin();

  try {
    await admin.from("devices").update({ connected: true, last_seen: new Date().toISOString() }).eq("id", device.deviceId);

    // Una orden que lleva horas esperando no debe ejecutarse de repente cuando el
    // dispositivo vuelve ("abre WhatsApp" a las 3 de la madrugada): se descarta.
    await admin.from("actions_log")
      .update({ status: "failed", result: "Caducada: el dispositivo no estuvo disponible a tiempo", executed_at: new Date().toISOString() })
      .eq("device_id", device.deviceId).eq("status", "pending")
      .lt("created_at", new Date(Date.now() - ACTION_TTL_MS).toISOString());

    const deadline = Date.now() + waitS * 1000;
    for (;;) {
      const actions = await claimPending(admin, device.deviceId);
      if (actions.length || Date.now() >= deadline) return res.status(200).json({ actions });
      await sleep(Math.min(POLL_EVERY_MS, Math.max(0, deadline - Date.now())));
    }
  } catch (e) {
    return res.status(500).json({ error: e instanceof Error ? e.message : "error interno" });
  }
}
