import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedUser } from "../../src/lib/auth";
import { supabaseForUser } from "../../src/lib/supabaseForUser";
import { ACTION_TTL_MS } from "../../src/lib/permissions";

/**
 * Cierra el ciclo del permiso REQUIERE_CONFIRMACION: el USUARIO (con su
 * sesión, no el dispositivo) aprueba (-> 'pending') o rechaza (-> 'blocked').
 * Una petición vieja no se puede aprobar: aprobar "apaga el PC" tres horas
 * después de pedirlo, cuando ya nadie se acuerda, sería peligroso.
 */
export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "método no permitido" });
  }
  const user = await getAuthedUser(req);
  if (!user) return res.status(401).json({ error: "no autenticado" });

  const { action_id, approve } = (req.body ?? {}) as { action_id?: unknown; approve?: unknown };
  if (typeof action_id !== "string" || !action_id || typeof approve !== "boolean") {
    return res.status(400).json({ error: "action_id (texto) y approve (true/false) son obligatorios" });
  }

  const cutoff = new Date(Date.now() - ACTION_TTL_MS).toISOString();
  const { data, error } = await supabaseForUser(user.accessToken)
    .from("actions_log")
    .update({ status: approve ? "pending" : "blocked", result: approve ? null : "Rechazada por el usuario" })
    .eq("id", action_id)
    .eq("status", "awaiting_confirmation")
    .gt("created_at", cutoff)
    .select("id, status")
    .maybeSingle();

  if (error) return res.status(500).json({ error: error.message });
  if (!data) return res.status(409).json({ error: "esa acción no existe, no es tuya, ya no espera confirmación o caducó (más de 1 hora)" });
  return res.status(200).json({ ok: true, status: data.status });
}
