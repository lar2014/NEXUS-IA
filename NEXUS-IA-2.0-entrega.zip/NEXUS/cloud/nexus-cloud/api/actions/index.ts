import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedUser } from "../../src/lib/auth";
import { supabaseForUser } from "../../src/lib/supabaseForUser";
import { validateAction } from "../../src/lib/actionsSchema";
import { createAction } from "../../src/lib/actionsService";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const user = await getAuthedUser(req);
  if (!user) return res.status(401).json({ error: "no autenticado" });
  const db = supabaseForUser(user.accessToken);

  if (req.method === "GET") {
    const { data, error } = await db.from("actions_log").select("*").order("created_at", { ascending: false }).limit(50);
    if (error) return res.status(500).json({ error: error.message });
    return res.status(200).json({ actions: data });
  }

  if (req.method === "POST") {
    const validated = validateAction(req.body);
    if (!validated.ok) return res.status(400).json({ error: validated.error });

    // Mismo camino único que usa el cerebro (src/lib/actionsService.ts).
    const created = await createAction(db, user.userId, validated.action);
    if (!created.ok) return res.status(created.status).json({ error: created.error, ...created.extra });

    // `delivered: false` es literal: se registra y se aplica el permiso; el
    // Agent la recoge en su siguiente sondeo (largo en PC, cada ~15 min en Android).
    return res.status(202).json({ action_log: created.log, delivered: false });
  }

  res.setHeader("Allow", "GET, POST");
  return res.status(405).json({ error: "método no permitido" });
}
