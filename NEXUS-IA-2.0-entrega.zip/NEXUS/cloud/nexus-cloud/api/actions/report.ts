import type { VercelRequest, VercelResponse } from "@vercel/node";
import { getAuthedDevice } from "../../src/lib/deviceAuth";
import { supabaseAdmin } from "../../src/lib/supabaseAdmin";

// 'awaiting_device': el propio dispositivo pide confirmación local (p. ej. el HUD del PC).
const VALID_STATUSES = ["executed", "failed", "awaiting_device"];
// Solo se puede reportar sobre una acción que el dispositivo tiene en marcha: nunca
// reescribir una ya ejecutada, bloqueada o pendiente de aprobar del usuario.
const REPORTABLE_FROM = ["delivered", "pending", "awaiting_device"];

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "método no permitido" });
  }
  const device = await getAuthedDevice(req);
  if (!device) return res.status(401).json({ error: "dispositivo no autenticado" });

  const { action_id, status, result } = (req.body ?? {}) as { action_id?: unknown; status?: unknown; result?: unknown };
  if (typeof action_id !== "string" || !action_id || typeof status !== "string") {
    return res.status(400).json({ error: "action_id y status son obligatorios" });
  }
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status debe ser uno de: ${VALID_STATUSES.join(", ")}` });
  }

  const { data, error } = await supabaseAdmin()
    .from("actions_log")
    .update({
      status,
      result: typeof result === "string" ? result.slice(0, 1000) : null,
      executed_at: status === "awaiting_device" ? null : new Date().toISOString(),
    })
    .eq("id", action_id)
    .eq("device_id", device.deviceId) // un dispositivo no puede reportar acciones de otro
    .in("status", REPORTABLE_FROM)
    .select("id")
    .maybeSingle();

  if (error) return res.status(500).json({ error: error.message });
  if (!data) return res.status(404).json({ error: "acción no encontrada para este dispositivo, o ya no admite resultado" });
  return res.status(200).json({ ok: true });
}
