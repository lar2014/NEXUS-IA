import type { VercelRequest, VercelResponse } from "@vercel/node";
import { requireEnv } from "../src/lib/env";
import { ACTION_TYPES } from "../src/lib/actionsSchema";
import { DEFAULT_PERMISSIONS } from "../src/lib/permissions";
import { PROVIDER_DEFAULT_MODELS } from "../src/lib/providers";

/**
 * Configuración PÚBLICA para el panel web: la URL de Supabase y la clave
 * publicable (protegida por RLS), NUNCA la service_role. También las listas que
 * el panel necesita y que no deben tener una copia propia que se desincronice.
 */
export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "método no permitido" });
  }
  try {
    const payload = {
      supabaseUrl: requireEnv("SUPABASE_URL"),
      supabaseAnonKey: requireEnv("SUPABASE_ANON_KEY"),
      actionTypes: ACTION_TYPES,
      defaultPermissions: DEFAULT_PERMISSIONS,
      providerDefaults: PROVIDER_DEFAULT_MODELS,
    };
    res.setHeader("Cache-Control", "public, max-age=300");
    return res.status(200).json(payload);
  } catch (err) {
    res.setHeader("Cache-Control", "no-store");
    return res.status(503).json({ error: err instanceof Error ? err.message : "configuración incompleta" });
  }
}
