"use strict";
/*
 * Panel de Nexus Cloud. Sin dependencias ni scripts de terceros.
 *  - La sesión (JWT de Supabase Auth) se guarda en localStorage. Es la práctica
 *    habitual para una SPA; el riesgo es XSS, por eso: (1) no se usa innerHTML
 *    en ningún sitio (todo el contenido dinámico entra con textContent) y
 *    (2) la CSP de vercel.json prohíbe scripts inline y de otros orígenes.
 *  - Solo se usa la clave PUBLICABLE (viene de /api/config). La service_role
 *    no existe en el navegador y no debe existir nunca.
 */

const LS_KEY = "nexus_session";
const DEVICE_TYPES = [["pc", "PC (Windows)"], ["android", "Android"], ["ios", "iOS"], ["mac", "Mac"], ["linux", "Linux"], ["nexus_room", "Nexus Room"]];
const PERM_LEVELS = [["", "Por defecto"], ["PERMITIDO", "Permitido"], ["REQUIERE_CONFIRMACION", "Pide confirmación"], ["BLOQUEADO", "Bloqueado"]];
const PROVIDERS = [["gemini", "Google Gemini"], ["anthropic", "Anthropic (Claude)"], ["openai", "OpenAI"], ["openrouter", "OpenRouter"]];
const PERM_LABEL = { PERMITIDO: "Permitido", REQUIERE_CONFIRMACION: "Pide confirmación", BLOQUEADO: "Bloqueado" };
const TARGET_HINTS = {
  OPEN_APP: "App a abrir (p. ej. whatsapp)", OPEN_URL: "Dirección (p. ej. https://…)", SEARCH_WEB: "Qué buscar",
  SET_VOLUME: "Volumen de 0 a 100", OPEN_FILE: "Ruta del archivo", CREATE_FILE: "Ruta del archivo",
  CREATE_FOLDER: "Ruta de la carpeta", SEND_MESSAGE: "Destinatario", CONTROL_MEDIA: "Orden (p. ej. pause_video)",
};
const STATUS = {
  pending: ["En cola", "info"], awaiting_confirmation: ["Espera tu aprobación", "warn"], confirmed: ["Confirmada", "info"],
  delivered: ["Entregada", "info"], awaiting_device: ["Espera confirmar en el dispositivo", "warn"],
  executed: ["Ejecutada", "ok"], failed: ["Falló", "err"], blocked: ["Bloqueada", "err"],
};
const AUTH_ERRORS = {
  "Invalid login credentials": "Correo o contraseña incorrectos.",
  "Email not confirmed": "Aún no has confirmado tu correo. Revisa tu bandeja de entrada.",
  "User already registered": "Ya existe una cuenta con ese correo.",
};

let cfg = null;
let session = null;
let devices = [];
let authMode = "login";
let refreshPromise = null;
let pollTimer = null;
let toastTimer = null;

const $ = (sel) => document.querySelector(sel);

/** Crea un elemento. Todo el texto entra por textContent/createTextNode: nunca se interpreta como HTML. */
function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v === false || v === null || v === undefined) continue;
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : String(v));
  }
  for (const kid of kids) e.append(kid);
  return e;
}
function options(list, selected) {
  return list.map(([value, label]) => el("option", { value, text: label, selected: value === selected }));
}
function toast(msg, kind = "") {
  const t = $("#toast");
  t.textContent = msg;
  t.className = kind;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 6000);
}
function fmtDate(iso) {
  return iso ? new Date(iso).toLocaleString("es-ES", { dateStyle: "short", timeStyle: "short" }) : "—";
}
function ago(iso) {
  if (!iso) return "nunca";
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return "hace unos segundos";
  const m = Math.round(s / 60);
  if (m < 60) return `hace ${m} min`;
  const h = Math.round(m / 60);
  return h < 48 ? `hace ${h} h` : `hace ${Math.round(h / 24)} días`;
}

/* ───────────── sesión / autenticación (Supabase Auth por REST) ───────────── */

function loadSession() {
  try { return JSON.parse(localStorage.getItem(LS_KEY)); } catch { return null; }
}
function saveSession(s) { session = s; localStorage.setItem(LS_KEY, JSON.stringify(s)); }
function clearSession() { session = null; localStorage.removeItem(LS_KEY); }
function sessionFrom(d, fallbackEmail) {
  return {
    access_token: d.access_token,
    refresh_token: d.refresh_token,
    expires_at: d.expires_at ? d.expires_at * 1000 : Date.now() + (d.expires_in || 3600) * 1000,
    email: (d.user && d.user.email) || fallbackEmail || "",
  };
}
async function authCall(path, body, token) {
  const headers = { "Content-Type": "application/json", apikey: cfg.supabaseAnonKey };
  if (token) headers.Authorization = `Bearer ${token}`;
  const r = await fetch(`${cfg.supabaseUrl}/auth/v1/${path}`, { method: "POST", headers, body: JSON.stringify(body || {}) });
  const text = await r.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { /* no era JSON */ }
  if (!r.ok) throw new Error(data.error_description || data.msg || data.message || data.error || `Error ${r.status}`);
  return data;
}
/** Un solo refresco a la vez: los refresh tokens rotan y usar el mismo dos veces lo invalida. */
function refreshSession() {
  if (!session || !session.refresh_token) return Promise.reject(new Error("sin sesión"));
  if (!refreshPromise) {
    refreshPromise = (async () => {
      try {
        const d = await authCall("token?grant_type=refresh_token", { refresh_token: session.refresh_token });
        saveSession(sessionFrom(d, session.email));
      } catch {
        clearSession(); stopPolling(); showAuth();
        throw new Error("Tu sesión ha caducado. Vuelve a entrar.");
      } finally { refreshPromise = null; }
    })();
  }
  return refreshPromise;
}
async function api(path, { method = "GET", body } = {}) {
  if (session && session.expires_at - Date.now() < 60000) await refreshSession();
  const send = () => fetch(path, {
    method,
    headers: { Authorization: `Bearer ${session.access_token}`, ...(body ? { "Content-Type": "application/json" } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let res = await send();
  if (res.status === 401) { await refreshSession(); res = await send(); }
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { /* no era JSON */ }
  if (!res.ok) throw Object.assign(new Error(data.error || `Error ${res.status}`), { status: res.status, data });
  return data;
}

/* ───────────── vistas ───────────── */

function show(view) {
  for (const id of ["loading", "auth-view", "main-view"]) $(`#${id}`).hidden = id !== view;
  $("#userbar").hidden = view !== "main-view";
}
function showAuth() { show("auth-view"); }
function setAuthMode(mode) {
  authMode = mode;
  const signup = mode === "signup";
  $("#auth-title").textContent = signup ? "Crear cuenta" : "Entrar";
  $("#auth-submit").textContent = signup ? "Crear cuenta" : "Entrar";
  $("#auth-switch-text").textContent = signup ? "¿Ya tienes cuenta?" : "¿No tienes cuenta?";
  $("#auth-switch").textContent = signup ? "Entrar" : "Crear cuenta";
  $("#password").setAttribute("autocomplete", signup ? "new-password" : "current-password");
  $("#password").setAttribute("minlength", signup ? "8" : "6");
}
async function enterApp() {
  show("main-view");
  $("#user-email").textContent = session.email;
  await loadAll();
  startPolling();
}
async function loadAll() {
  await Promise.all([loadDevices(), loadActions(), loadProviders()]);
}
function startPolling() {
  stopPolling();
  pollTimer = setInterval(() => {
    if (document.hidden || !session) return;
    loadActions().catch(() => {});
    // No se repinta la lista de dispositivos si hay un editor de permisos abierto: se perdería lo que estás tocando.
    if (!document.querySelector("#devices details[open]")) loadDevices().catch(() => {});
  }, 15000);
}
function stopPolling() { clearInterval(pollTimer); pollTimer = null; }

/* ───────────── dispositivos ───────────── */

async function loadDevices() {
  try {
    devices = (await api("/api/devices")).devices || [];
    renderDevices();
    renderActionDevices();
  } catch (e) { toast(e.message, "err"); }
}
function deviceStatus(d) {
  if (d.pairing_expires_at) {
    return new Date(d.pairing_expires_at) > new Date()
      ? ["Pendiente de vincular", "warn", `El código caduca a las ${new Date(d.pairing_expires_at).toLocaleTimeString("es-ES", { timeStyle: "short" })}`]
      : ["Código caducado", "err", "Nadie lo introdujo a tiempo. Bórralo y genera otro."];
  }
  return d.online ? ["Online", "ok", `Último latido ${ago(d.last_seen)}`] : ["Offline", "err", `Último latido ${ago(d.last_seen)}`];
}
function renderDevices() {
  const box = $("#devices");
  box.replaceChildren();
  if (!devices.length) { box.append(el("p", { class: "empty", text: "Todavía no has vinculado ningún dispositivo." })); return; }
  for (const d of devices) {
    const [label, kind, detail] = deviceStatus(d);
    const caps = Array.isArray(d.capabilities) ? d.capabilities : [];
    const perms = d.permissions && typeof d.permissions === "object" ? d.permissions : {};

    const grid = el("div", { class: "perm-grid" });
    for (const t of cfg.actionTypes) {
      const defLabel = PERM_LABEL[(cfg.defaultPermissions || {})[t]] || "según el tipo";
      const levels = [["", `Por defecto (${defLabel})`], ...PERM_LEVELS.slice(1)];
      const sel = el("select", { "aria-label": `Permiso ${t}`, "data-action": t }, ...options(levels, perms[t] || ""));
      grid.append(el("div", { class: "perm-row" }, el("span", { text: t }), sel));
    }
    const save = el("button", { type: "button", class: "primary", text: "Guardar permisos", onclick: async () => {
      const map = {};
      grid.querySelectorAll("select").forEach((s) => { if (s.value) map[s.dataset.action] = s.value; });
      try { await api(`/api/devices/${d.id}`, { method: "PATCH", body: { permissions: map } }); toast("Permisos guardados", "ok"); await loadDevices(); }
      catch (e) { toast(e.message, "err"); }
    } });

    const del = el("button", { type: "button", class: "danger", text: "Desvincular", onclick: async () => {
      if (!confirm(`¿Desvincular "${d.name}"? Se borrará también su historial de acciones.`)) return;
      try { await api(`/api/devices/${d.id}`, { method: "DELETE" }); toast("Dispositivo eliminado", "ok"); await loadAll(); }
      catch (e) { toast(e.message, "err"); }
    } });

    box.append(el("div", { class: "device" },
      el("div", { class: "device-head" },
        el("div", {}, el("div", { class: "device-name", text: d.name }), el("div", { class: "muted", text: `${d.type} · ${detail}` })),
        el("span", { class: `badge ${kind}`, text: label })),
      el("div", { class: "chips" }, ...(caps.length ? caps.map((c) => el("span", { class: "chip", text: c })) : [el("span", { class: "chip", text: "Sin capacidades anunciadas" })])),
      el("details", {}, el("summary", { text: "Permisos de este dispositivo" }),
        el("p", { class: "hint", text: "Si no eliges nada, se aplica la política por defecto de cada acción (la que ves entre paréntesis). El propio dispositivo aún puede pedir su confirmación." }), grid, save),
      el("div", { class: "device-actions" }, del)));
  }
}

/* ───────────── vincular ───────────── */

async function onPair(e) {
  e.preventDefault();
  const name = $("#pair-name").value.trim();
  const type = $("#pair-type").value;
  try {
    const r = await api("/api/devices/pairing", { method: "POST", body: { name, type } });
    const how = type === "android"
      ? "Abre la app Nexus Agent en el móvil e introduce este código."
      : type === "pc"
        ? "Ojo: el Agent de Windows todavía no sabe vincularse con la nube (pendiente de construir)."
        : "Introduce este código en el Agent de ese dispositivo.";
    const box = $("#pair-result");
    box.replaceChildren(
      el("div", { class: "muted", text: "Código de vinculación" }),
      el("div", { class: "pair-code", text: r.pairing_code }),
      el("div", { class: "muted", text: `Caduca a las ${new Date(r.expires_at).toLocaleTimeString("es-ES", { timeStyle: "short" })} (10 minutos). Un solo uso.` }),
      el("div", { text: how }));
    box.hidden = false;
    $("#pair-name").value = "";
    await loadDevices();
  } catch (err) { toast(err.message, "err"); }
}

/* ───────────── enviar acción ───────────── */

function renderActionDevices() {
  const sel = $("#action-device");
  const linked = devices.filter((d) => !d.pairing_expires_at);
  sel.replaceChildren(...(linked.length ? options(linked.map((d) => [d.id, `${d.name} (${d.type})`])) : [el("option", { value: "", text: "No hay dispositivos vinculados" })]));
  $("#action-submit").disabled = !linked.length;
}
function updateTargetHint() {
  const t = $("#action-type").value;
  $("#action-target").placeholder = TARGET_HINTS[t] || "Destino (opcional)";
}
async function onSendAction(e) {
  e.preventDefault();
  const body = { action: $("#action-type").value, device_id: $("#action-device").value, target: $("#action-target").value.trim(), params: {} };
  const out = $("#action-result");
  try {
    const r = await api("/api/actions", { method: "POST", body });
    const st = r.action_log.status;
    out.textContent = st === "blocked" ? "Bloqueada: el permiso de ese dispositivo no la deja pasar."
      : st === "awaiting_confirmation" ? "Esperando tu aprobación: apruébala más abajo, en Acciones recientes."
      : "En cola. El dispositivo la ejecutará en su próximo sondeo (el Agent Android tarda hasta ~15 min; usa «Sincronizar ahora» en la app para probar).";
    out.hidden = false;
    $("#action-target").value = "";
    await loadActions();
  } catch (err) { out.hidden = true; toast(err.message, "err"); }
}

/* ───────────── acciones recientes ───────────── */

async function loadActions() {
  try { renderActions((await api("/api/actions")).actions || []); }
  catch (e) { toast(e.message, "err"); }
}
async function decide(id, approve) {
  try { await api("/api/actions/confirm", { method: "POST", body: { action_id: id, approve } }); toast(approve ? "Aprobada" : "Rechazada", "ok"); await loadActions(); }
  catch (e) { toast(e.message, "err"); await loadActions(); }
}
function renderActions(list) {
  const box = $("#actions");
  box.replaceChildren();
  if (!list.length) { box.append(el("p", { class: "empty", text: "Aún no hay acciones." })); return; }
  const names = Object.fromEntries(devices.map((d) => [d.id, d.name]));
  for (const a of list) {
    const [label, kind] = STATUS[a.status] || [a.status, "info"];
    const card = el("div", { class: "action" },
      el("div", { class: "action-line" },
        el("div", {}, el("div", { class: "action-title", text: a.target ? `${a.action_type} → ${a.target}` : a.action_type }),
          el("div", { class: "action-meta", text: `${names[a.device_id] || "dispositivo eliminado"} · ${fmtDate(a.created_at)}` })),
        el("span", { class: `badge ${kind}`, text: label })));
    if (a.result) card.append(el("div", { class: "action-result", text: a.result }));
    if (a.status === "awaiting_confirmation") {
      card.append(el("div", { class: "device-actions" },
        el("button", { type: "button", class: "primary", text: "Aprobar", onclick: () => decide(a.id, true) }),
        el("button", { type: "button", class: "danger", text: "Rechazar", onclick: () => decide(a.id, false) })));
    }
    box.append(card);
  }
}

/* ───────────── hablar con Nexus (el cerebro) ───────────── */

function renderCommandResult(r) {
  const box = $("#command-result");
  box.replaceChildren();
  if (r.reply) box.append(el("div", { class: "command-reply", text: r.reply }));
  if (r.clarification) box.append(el("div", { class: "command-reply", text: `❓ ${r.clarification}` }));
  if (!r.reply && !r.clarification && !(r.actions || []).length) box.append(el("div", { class: "muted", text: "Nexus no ha propuesto ninguna acción." }));
  for (const a of r.actions || []) {
    const [label, kind] = a.error ? ["No creada", "err"] : (STATUS[a.status] || [a.status, "info"]);
    const what = a.target ? `${a.action} → ${a.target}` : a.action;
    box.append(el("div", { class: "command-action" },
      el("div", {}, el("div", { text: what }), el("div", { class: "muted", text: a.error ? `${a.device_name || "?"} · ${a.error}` : a.device_name })),
      el("span", { class: `badge ${kind}`, text: label })));
  }
  if ((r.warnings || []).length) box.append(el("div", { class: "command-foot", text: `Avisos: ${r.warnings.join(" · ")}` }));
  if (r.provider) box.append(el("div", { class: "command-foot", text: `Interpretado con ${r.provider} · ${r.model}` }));
  box.hidden = false;
}
async function onCommand(e) {
  e.preventDefault();
  const message = $("#command-input").value.trim();
  if (!message) return;
  const btn = $("#command-submit");
  const box = $("#command-result");
  btn.disabled = true;
  box.replaceChildren(el("div", { class: "muted", text: "Pensando…" }));
  box.hidden = false;
  try {
    renderCommandResult(await api("/api/command", { method: "POST", body: { message } }));
    $("#command-input").value = "";
    await loadActions();
  } catch (err) { box.hidden = true; toast(err.message, "err"); }
  finally { btn.disabled = false; }
}

/* ───────────── proveedores ───────────── */

function updateProviderHint() {
  const def = (cfg.providerDefaults || {})[$("#provider-name").value];
  $("#provider-model").placeholder = def ? `Modelo (por defecto: ${def})` : "Modelo (obligatorio, p. ej. anthropic/claude-haiku-4.5)";
  $("#provider-model").required = !def;
}

async function loadProviders() {
  try {
    const list = (await api("/api/providers")).providers || [];
    const box = $("#providers");
    box.replaceChildren();
    if (!list.length) { box.append(el("p", { class: "empty", text: "No has guardado ninguna clave todavía." })); return; }
    for (const p of list) {
      const del = el("button", { type: "button", class: "danger", text: "Eliminar", onclick: async () => {
        if (!confirm(`¿Eliminar la clave de ${p.provider}? Se borra también del Vault y Nexus dejará de poder usarla.`)) return;
        try { await api(`/api/providers?id=${encodeURIComponent(p.id)}`, { method: "DELETE" }); toast("Clave eliminada", "ok"); await loadProviders(); }
        catch (e) { toast(e.message, "err"); }
      } });
      const model = p.model || (cfg.providerDefaults || {})[p.provider] || "modelo por elegir";
      box.append(el("div", { class: "provider action-line" },
        el("div", {}, el("div", { class: "action-title", text: p.label ? `${p.provider} · ${p.label}` : p.provider }),
          el("div", { class: "action-meta", text: `${model} · guardada el ${fmtDate(p.created_at)} · clave cifrada` })),
        el("div", { class: "device-actions" }, p.is_default ? el("span", { class: "badge ok", text: "En uso" }) : "", del)));
    }
  } catch (e) { toast(e.message, "err"); }
}
async function onSaveProvider(e) {
  e.preventDefault();
  const keyInput = $("#provider-key");
  try {
    await api("/api/providers", { method: "POST", body: { provider: $("#provider-name").value, label: $("#provider-label").value.trim(), model: $("#provider-model").value.trim(), api_key: keyInput.value } });
    toast("Clave guardada y cifrada", "ok");
    $("#provider-label").value = ""; $("#provider-model").value = "";
    await loadProviders();
  } catch (err) { toast(err.message, "err"); }
  finally { keyInput.value = ""; } // la clave no se queda en el DOM, salga bien o mal
}

/* ───────────── arranque ───────────── */

async function onAuthSubmit(e) {
  e.preventDefault();
  const email = $("#email").value.trim();
  const password = $("#password").value;
  if (authMode === "signup" && password.length < 8) { toast("La contraseña debe tener al menos 8 caracteres.", "err"); return; }
  const btn = $("#auth-submit");
  btn.disabled = true;
  try {
    const d = await authCall(authMode === "signup" ? "signup" : "token?grant_type=password", { email, password });
    $("#password").value = "";
    if (d.access_token) { saveSession(sessionFrom(d, email)); await enterApp(); }
    else { setAuthMode("login"); toast("Cuenta creada. Revisa tu correo para confirmarla y luego entra.", "ok"); }
  } catch (err) { toast(AUTH_ERRORS[err.message] || err.message, "err"); }
  finally { btn.disabled = false; }
}
async function logout() {
  const token = session && session.access_token;
  stopPolling();
  clearSession();
  showAuth();
  try { if (token) await authCall("logout", {}, token); } catch { /* da igual: la sesión local ya se borró */ }
}

async function init() {
  $("#pair-type").replaceChildren(...options(DEVICE_TYPES, "android"));
  $("#provider-name").replaceChildren(...options(PROVIDERS, "gemini"));
  $("#auth-form").addEventListener("submit", onAuthSubmit);
  $("#auth-switch").addEventListener("click", () => setAuthMode(authMode === "login" ? "signup" : "login"));
  $("#logout").addEventListener("click", logout);
  $("#pair-form").addEventListener("submit", onPair);
  $("#action-form").addEventListener("submit", onSendAction);
  $("#action-type").addEventListener("change", updateTargetHint);
  $("#provider-form").addEventListener("submit", onSaveProvider);
  $("#provider-name").addEventListener("change", updateProviderHint);
  $("#command-form").addEventListener("submit", onCommand);
  $("#refresh-devices").addEventListener("click", loadDevices);
  $("#refresh-actions").addEventListener("click", loadActions);

  try {
    const r = await fetch("/api/config");
    cfg = await r.json();
    if (!r.ok || !cfg.supabaseUrl || !cfg.supabaseAnonKey || !Array.isArray(cfg.actionTypes)) {
      throw new Error(cfg.error || "la respuesta de configuración está incompleta");
    }
  } catch (e) {
    show("loading");
    $("#loading").replaceChildren(el("p", { class: "muted", text: `No se pudo cargar la configuración de Nexus Cloud: ${e.message}` }));
    return;
  }
  $("#action-type").replaceChildren(...options(cfg.actionTypes.map((t) => [t, t])));
  updateTargetHint();
  updateProviderHint();

  session = loadSession();
  if (session && session.refresh_token) {
    try { await enterApp(); } catch { showAuth(); }
  } else {
    showAuth();
  }
}
init().catch((e) => {
  // Red de seguridad: cualquier fallo inesperado del arranque se ve, en vez de dejar «Cargando…» para siempre.
  show("loading");
  $("#loading").replaceChildren(el("p", { class: "muted", text: `Error inesperado al arrancar: ${e && e.message ? e.message : e}` }));
});
