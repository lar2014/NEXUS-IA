import { afterEach, describe, it } from "node:test";
import assert from "node:assert/strict";
import { getAdapter, PROVIDER_DEFAULT_MODELS, ProviderError } from "../src/lib/providers";
import { postJson } from "../src/lib/providers/http";

const realFetch = globalThis.fetch;
afterEach(() => { globalThis.fetch = realFetch; });

interface Call { url: string; headers: Record<string, string>; body: Record<string, unknown> }
function mockFetch(respond: (c: Call) => Response | Promise<Response>): Call[] {
  const calls: Call[] = [];
  globalThis.fetch = (async (url: string, init: RequestInit) => {
    const call = { url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) as Record<string, unknown> };
    calls.push(call);
    return respond(call);
  }) as unknown as typeof fetch;
  return calls;
}
const json = (obj: unknown, status = 200) => new Response(JSON.stringify(obj), { status });
const REQ = { system: "SYS", user: "USER", model: "m", apiKey: "sk-SECRET-123", timeoutMs: 2000 };

describe("adaptadores", () => {
  it("Gemini: clave en cabecera (no en la URL), JSON forzado, modelo codificado", async () => {
    const calls = mockFetch(() => json({ candidates: [{ content: { parts: [{ text: '{"ok":1}' }] } }] }));
    const out = await getAdapter("gemini").complete({ ...REQ, model: "gemini-2.5-flash" });
    assert.equal(out, '{"ok":1}');
    assert.ok(calls[0].url.endsWith("/models/gemini-2.5-flash:generateContent"));
    assert.ok(!calls[0].url.includes("SECRET"), "la clave no debe ir en la URL");
    assert.equal(calls[0].headers["x-goog-api-key"], REQ.apiKey);
    assert.equal((calls[0].body.generationConfig as Record<string, unknown>).responseMimeType, "application/json");
  });
  it("Anthropic: cabeceras y forma de la petición", async () => {
    const calls = mockFetch(() => json({ content: [{ type: "text", text: "hola" }] }));
    assert.equal(await getAdapter("anthropic").complete(REQ), "hola");
    assert.equal(calls[0].url, "https://api.anthropic.com/v1/messages");
    assert.equal(calls[0].headers["x-api-key"], REQ.apiKey);
    assert.equal(calls[0].headers["anthropic-version"], "2023-06-01");
    assert.equal(calls[0].body.system, "SYS");
  });
  it("OpenAI y OpenRouter: mismo protocolo, distinta URL", async () => {
    const calls = mockFetch(() => json({ choices: [{ message: { content: '{"a":1}' } }] }));
    await getAdapter("openai").complete(REQ);
    await getAdapter("openrouter").complete(REQ);
    assert.equal(calls[0].url, "https://api.openai.com/v1/chat/completions");
    assert.equal(calls[1].url, "https://openrouter.ai/api/v1/chat/completions");
    assert.equal(calls[0].headers.Authorization, `Bearer ${REQ.apiKey}`);
    assert.deepEqual(calls[0].body.response_format, { type: "json_object" });
  });
  it("modelos por defecto: OpenRouter no tiene (hay que elegirlo); 'custom' no está soportado", () => {
    assert.equal(PROVIDER_DEFAULT_MODELS.openrouter, null);
    assert.ok(PROVIDER_DEFAULT_MODELS.gemini);
    assert.throws(() => getAdapter("custom"), (e: unknown) => e instanceof ProviderError && e.kind === "unsupported");
    assert.throws(() => getAdapter("inventado"), ProviderError);
  });
});

describe("errores clasificados y sin filtrar la clave", () => {
  const kindFor = async (status: number, body: unknown = {}) => {
    mockFetch(() => json(body, status));
    try { await getAdapter("openai").complete(REQ); return "sin error"; }
    catch (e) { return e instanceof ProviderError ? e.kind : "otro"; }
  };
  it("401/403 auth, 404 model, 429 rate, 500 upstream", async () => {
    assert.equal(await kindFor(401), "auth");
    assert.equal(await kindFor(403), "auth");
    assert.equal(await kindFor(404), "model");
    assert.equal(await kindFor(429), "rate");
    assert.equal(await kindFor(500), "upstream");
  });
  it("si el proveedor repite la clave en su error, sale censurada", async () => {
    mockFetch(() => json({ error: "Incorrect API key provided: sk-SECRET-123" }, 401));
    await assert.rejects(() => getAdapter("openai").complete(REQ), (e: unknown) => {
      const msg = (e as Error).message;
      assert.ok(!msg.includes("sk-SECRET-123"), "la clave NO debe aparecer");
      assert.ok(msg.includes("***"));
      return true;
    });
  });
  it("respuesta vacía, no-JSON y fallo de red", async () => {
    mockFetch(() => json({ choices: [{ message: { content: "  " } }] }));
    await assert.rejects(() => getAdapter("openai").complete(REQ), (e: unknown) => (e as ProviderError).kind === "empty");
    mockFetch(() => new Response("<html>", { status: 200 }));
    await assert.rejects(() => getAdapter("openai").complete(REQ), (e: unknown) => (e as ProviderError).kind === "upstream");
    globalThis.fetch = (async () => { throw new Error("ECONNRESET sk-SECRET-123"); }) as unknown as typeof fetch;
    await assert.rejects(() => getAdapter("openai").complete(REQ), (e: unknown) => {
      const pe = e as ProviderError;
      return pe.kind === "network" && !pe.message.includes("sk-SECRET-123");
    });
  });
  it("timeout: aborta y lo clasifica como timeout", async () => {
    globalThis.fetch = ((_url: string, init: RequestInit) => new Promise((_res, rej) => {
      init.signal?.addEventListener("abort", () => rej(new Error("aborted")));
    })) as unknown as typeof fetch;
    await assert.rejects(() => postJson("https://x.test", {}, {}, { timeoutMs: 40, secrets: [] }), (e: unknown) => (e as ProviderError).kind === "timeout");
  });
});
