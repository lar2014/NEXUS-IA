import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { ACTION_TYPES } from "../src/lib/actionsSchema";
import { DEFAULT_PERMISSIONS, effectivePermission, initialStatusFor } from "../src/lib/permissions";
import { isOnline } from "../src/lib/presence";

describe("permisos por defecto", () => {
  it("cubren TODOS los tipos de acción (si se añade uno nuevo, esta prueba obliga a decidir su política)", () => {
    for (const t of ACTION_TYPES) assert.ok(DEFAULT_PERMISSIONS[t], `falta la política de ${t}`);
  });
  it("apagar, bloquear y enviar mensajes piden confirmación; abrir una app no", () => {
    assert.equal(DEFAULT_PERMISSIONS.SHUTDOWN_DEVICE, "REQUIERE_CONFIRMACION");
    assert.equal(DEFAULT_PERMISSIONS.LOCK_DEVICE, "REQUIERE_CONFIRMACION");
    assert.equal(DEFAULT_PERMISSIONS.SEND_MESSAGE, "REQUIERE_CONFIRMACION");
    assert.equal(DEFAULT_PERMISSIONS.OPEN_APP, "PERMITIDO");
  });
  it("el permiso explícito manda; un valor basura se ignora y cae al de por defecto", () => {
    assert.equal(effectivePermission("BLOQUEADO", "OPEN_APP"), "BLOQUEADO");
    assert.equal(effectivePermission("PERMITIDO", "SHUTDOWN_DEVICE"), "PERMITIDO");
    assert.equal(effectivePermission("lo-que-sea", "SHUTDOWN_DEVICE"), "REQUIERE_CONFIRMACION");
    assert.equal(effectivePermission(undefined, "OPEN_APP"), "PERMITIDO");
  });
  it("estado inicial según permiso", () => {
    assert.equal(initialStatusFor("PERMITIDO"), "pending");
    assert.equal(initialStatusFor("REQUIERE_CONFIRMACION"), "awaiting_confirmation");
    assert.equal(initialStatusFor("BLOQUEADO"), "blocked");
  });
});

describe("presencia", () => {
  const now = Date.parse("2026-09-28T12:00:00Z");
  it("online si el último latido es reciente; offline si es viejo, nulo o connected=false", () => {
    assert.equal(isOnline({ connected: true, last_seen: "2026-09-28T11:50:00Z" }, now), true);
    assert.equal(isOnline({ connected: true, last_seen: "2026-09-28T11:30:00Z" }, now), false);
    assert.equal(isOnline({ connected: true, last_seen: null }, now), false);
    assert.equal(isOnline({ connected: false, last_seen: "2026-09-28T11:59:00Z" }, now), false);
  });
});
