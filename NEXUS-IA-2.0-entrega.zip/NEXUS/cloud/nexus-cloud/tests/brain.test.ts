import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { BrainParseError, buildSystemPrompt, extractJson, parsePlan, type DeviceInfo } from "../src/lib/brain";

const android: DeviceInfo = { id: "dev-android", name: "Mi Android", type: "android", capabilities: ["OPEN_APP", "SET_VOLUME"], online: true };
const pc: DeviceInfo = { id: "dev-pc", name: "PC de casa", type: "pc", capabilities: ["OPEN_APP", "SHUTDOWN_DEVICE"], online: true };
const devices = [android, pc];

describe("extractJson", () => {
  it("acepta JSON limpio, con vallas ```json y con texto alrededor", () => {
    assert.deepEqual(extractJson('{"a":1}'), { a: 1 });
    assert.deepEqual(extractJson('```json\n{"a":1}\n```'), { a: 1 });
    assert.deepEqual(extractJson('Claro, aquí está: {"a":1} ¡listo!'), { a: 1 });
  });
  it("lanza BrainParseError con basura", () => {
    assert.throws(() => extractJson("no hay json aquí"), BrainParseError);
    assert.throws(() => extractJson("{roto"), BrainParseError);
  });
});

describe("parsePlan (la salida del modelo NO es de fiar)", () => {
  it("plan correcto", () => {
    const p = parsePlan(JSON.stringify({ reply: "Abriendo WhatsApp.", clarification: null, actions: [{ action: "OPEN_APP", device_id: "dev-android", target: "whatsapp", params: {} }] }), devices);
    assert.equal(p.reply, "Abriendo WhatsApp.");
    assert.equal(p.actions.length, 1);
    assert.equal(p.actions[0].device_id, "dev-android");
    assert.deepEqual(p.warnings, []);
  });
  it("acepta el NOMBRE del dispositivo en lugar del id", () => {
    const p = parsePlan(JSON.stringify({ actions: [{ action: "OPEN_APP", device_id: "mi android", target: "chrome" }] }), devices);
    assert.equal(p.actions[0].device_id, "dev-android");
  });
  it("sin device_id: lo deduce SOLO si hay un único dispositivo capaz", () => {
    const unico = parsePlan(JSON.stringify({ actions: [{ action: "SHUTDOWN_DEVICE", target: "" }] }), devices);
    assert.equal(unico.actions[0].device_id, "dev-pc");
    const ambiguo = parsePlan(JSON.stringify({ actions: [{ action: "OPEN_APP", target: "chrome" }] }), devices);
    assert.equal(ambiguo.actions.length, 0);
    assert.match(ambiguo.warnings[0], /dispositivo/);
  });
  it("un device_id inventado se DESCARTA, no se 'corrige' hacia otro dispositivo", () => {
    const p = parsePlan(JSON.stringify({ actions: [{ action: "SHUTDOWN_DEVICE", device_id: "dev-de-otro-usuario", target: "" }] }), devices);
    assert.equal(p.actions.length, 0);
  });
  it("descarta acciones desconocidas y elementos que no son objetos", () => {
    const p = parsePlan(JSON.stringify({ actions: [{ action: "FORMAT_DISK", device_id: "dev-pc" }, "hola", null, 7] }), devices);
    assert.equal(p.actions.length, 0);
    assert.equal(p.warnings.length, 4);
  });
  it("máximo 3 acciones, avisando del recorte", () => {
    const acts = Array.from({ length: 5 }, () => ({ action: "OPEN_APP", device_id: "dev-android", target: "chrome" }));
    const p = parsePlan(JSON.stringify({ actions: acts }), devices);
    assert.equal(p.actions.length, 3);
    assert.ok(p.warnings.some((w) => w.includes("5 acciones")));
  });
  it("target numérico se convierte a texto; params que no es objeto pasa a {}", () => {
    const p = parsePlan(JSON.stringify({ actions: [{ action: "SET_VOLUME", device_id: "dev-android", target: 30, params: "x" }] }), devices);
    assert.equal(p.actions[0].target, "30");
    assert.deepEqual(p.actions[0].params, {});
  });
  it("aclaración sin acciones", () => {
    const p = parsePlan(JSON.stringify({ reply: "", clarification: "¿En el móvil o en el PC?", actions: [] }), devices);
    assert.equal(p.clarification, "¿En el móvil o en el PC?");
    assert.equal(p.actions.length, 0);
  });
  it("lo que no es un objeto JSON lanza BrainParseError", () => {
    assert.throws(() => parsePlan("[1,2,3]", devices), BrainParseError);
    assert.throws(() => parsePlan('"hola"', devices), BrainParseError);
  });
});

describe("buildSystemPrompt", () => {
  it("incluye los ids de los dispositivos, marca 'desconocidas' si no hay capacidades y no pide nada fuera del formato", () => {
    const prompt = buildSystemPrompt([android, { ...pc, capabilities: [] }]);
    assert.ok(prompt.includes("dev-android") && prompt.includes("dev-pc"));
    assert.ok(prompt.includes('"desconocidas"'));
    assert.ok(prompt.includes("SHUTDOWN_DEVICE"));
  });
});
