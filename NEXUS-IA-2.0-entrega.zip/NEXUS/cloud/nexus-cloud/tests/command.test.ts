import { afterEach, beforeEach, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createAction } from "../src/lib/actionsService";
import { runCommand } from "../src/lib/commandService";
import { FakeDb } from "./helpers/fakeDb";

const SECRET = "sk-SECRET-XYZ";
const NOW = Date.parse("2026-09-28T12:00:00Z");
const recent = new Date(NOW - 60_000).toISOString();

const android = { id: "dev-android", name: "Mi Android", type: "android", capabilities: ["OPEN_APP", "OPEN_URL", "SET_VOLUME"], permissions: {}, connected: true, last_seen: recent, pairing_code: null, user_id: "u1" };
const pc = { id: "dev-pc", name: "PC de casa", type: "pc", capabilities: ["OPEN_APP", "SHUTDOWN_DEVICE", "LOCK_DEVICE"], permissions: {}, connected: true, last_seen: recent, pairing_code: null, user_id: "u1" };
const tablet = { id: "dev-tablet", name: "Tablet", type: "android", capabilities: [], permissions: {}, connected: false, last_seen: null, pairing_code: "ABC-123", user_id: "u1" };
const gemini = { id: "cfg-gemini", provider: "gemini", model: null, is_default: true, created_at: "2026-09-01T00:00:00Z", user_id: "u1" };

const realFetch = globalThis.fetch;
let llmCalls: Array<{ url: string; headers: Record<string, string>; body: { systemInstruction?: { parts: Array<{ text: string }> } } & Record<string, unknown> }> = [];
let llmReply: () => Response = () => new Response("{}", { status: 500 });

const geminiOk = (plan: unknown) => () => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: typeof plan === "string" ? plan : JSON.stringify(plan) }] } }] }), { status: 200 });
const makeDeps = (db: FakeDb) => ({ db: db.asClient(), userId: "u1", now: () => NOW, getProviderKey: async () => SECRET as string | null });

beforeEach(() => {
  llmCalls = [];
  llmReply = geminiOk({ reply: "Abriendo.", clarification: null, actions: [] });
  globalThis.fetch = (async (url: string, init: RequestInit) => {
    llmCalls.push({ url, headers: init.headers as Record<string, string>, body: JSON.parse(String(init.body)) });
    return llmReply();
  }) as unknown as typeof fetch;
});
afterEach(() => { globalThis.fetch = realFetch; });

const openWhatsapp = { reply: "Abriendo WhatsApp en tu móvil.", clarification: null, actions: [{ action: "OPEN_APP", device_id: "dev-android", target: "whatsapp", params: {} }] };

describe("runCommand — el cerebro", () => {
  it("mensaje vacío o demasiado largo: 400 sin llamar a la IA", async () => {
    const db = new FakeDb({ devices: [android], provider_configs: [gemini] });
    assert.equal((await runCommand(makeDeps(db), { message: "   " })).status, 400);
    assert.equal((await runCommand(makeDeps(db), { message: "x".repeat(1001) })).status, 400);
    assert.equal(llmCalls.length, 0);
  });
  it("sin dispositivos vinculados: responde sin gastar una llamada a la IA (un dispositivo con código pendiente no cuenta)", async () => {
    const db = new FakeDb({ devices: [tablet], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal(out.status, 200);
    assert.match(String(out.body.reply), /dispositivo/);
    assert.equal(llmCalls.length, 0);
  });
  it("sin clave de IA guardada: 409 no_provider", async () => {
    const db = new FakeDb({ devices: [android] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal(out.status, 409);
    assert.equal(out.body.code, "no_provider");
  });

  it("camino feliz: 'abre WhatsApp' -> acción encolada en el móvil, con la clave del usuario y sin filtrarla", async () => {
    llmReply = geminiOk(openWhatsapp);
    const db = new FakeDb({ devices: [android, pc], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre WhatsApp en mi móvil" });

    assert.equal(out.status, 200);
    const acts = out.body.actions as Array<Record<string, unknown>>;
    assert.equal(acts.length, 1);
    assert.equal(acts[0].status, "pending");
    assert.equal(acts[0].device_name, "Mi Android");
    assert.equal(out.body.provider, "gemini");
    assert.equal(db.tables.actions_log.length, 1);
    assert.equal(db.tables.actions_log[0].user_id, "u1");
    assert.equal(db.tables.actions_log[0].device_id, "dev-android");

    // La llamada a la IA: modelo por defecto, clave SOLO en cabecera, ids de dispositivos en el prompt
    assert.ok(llmCalls[0].url.includes("gemini-2.5-flash"));
    assert.equal(llmCalls[0].headers["x-goog-api-key"], SECRET);
    const system = llmCalls[0].body.systemInstruction!.parts[0].text;
    assert.ok(system.includes("dev-android") && system.includes("dev-pc"));
    assert.ok(!system.includes(SECRET), "la clave no debe ir en el prompt");
    assert.ok(!JSON.stringify(out.body).includes(SECRET), "la clave no debe salir en la respuesta");
  });

  it("el modelo elegido por el usuario manda sobre el de por defecto", async () => {
    llmReply = geminiOk(openWhatsapp);
    const db = new FakeDb({ devices: [android], provider_configs: [{ ...gemini, model: "gemini-mio-1" }] });
    await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.ok(llmCalls[0].url.includes("gemini-mio-1"));
  });

  it("acciones sensibles: por defecto NO se ejecutan solas, esperan tu aprobación", async () => {
    llmReply = geminiOk({ reply: "Apagando.", actions: [{ action: "SHUTDOWN_DEVICE", device_id: "dev-pc", target: "" }] });
    const db = new FakeDb({ devices: [android, pc], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "apaga el pc" });
    assert.equal((out.body.actions as Array<Record<string, unknown>>)[0].status, "awaiting_confirmation");
    assert.equal(db.tables.actions_log[0].status, "awaiting_confirmation");
  });
  it("permisos explícitos del dispositivo: PERMITIDO salta la confirmación, BLOQUEADO la corta", async () => {
    llmReply = geminiOk({ reply: "ok", actions: [
      { action: "SHUTDOWN_DEVICE", device_id: "dev-pc", target: "" },
      { action: "OPEN_APP", device_id: "dev-pc", target: "chrome" },
    ] });
    const db = new FakeDb({ devices: [{ ...pc, permissions: { SHUTDOWN_DEVICE: "PERMITIDO", OPEN_APP: "BLOQUEADO" } }], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "apaga el pc y abre chrome" });
    const [a, b] = out.body.actions as Array<Record<string, unknown>>;
    assert.equal(a.status, "pending");
    assert.equal(b.status, "blocked");
  });

  it("SEGURIDAD: un device_id que no es del usuario se descarta y NO se crea nada", async () => {
    llmReply = geminiOk({ reply: "ok", actions: [{ action: "SHUTDOWN_DEVICE", device_id: "dev-de-otro-usuario", target: "" }] });
    const db = new FakeDb({ devices: [android, pc], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "apaga" });
    assert.equal((out.body.actions as unknown[]).length, 0);
    assert.equal(db.tables.actions_log.length, 0);
    assert.ok((out.body.warnings as string[]).length > 0);
  });
  it("una acción que el dispositivo no soporta se rechaza con motivo (no se encola)", async () => {
    llmReply = geminiOk({ reply: "ok", actions: [{ action: "SHUTDOWN_DEVICE", device_id: "dev-android", target: "" }] });
    const db = new FakeDb({ devices: [android, pc], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "apaga el móvil" });
    const a = (out.body.actions as Array<Record<string, unknown>>)[0];
    assert.equal(a.http_status, 422);
    assert.match(String(a.error), /no soporta/);
    assert.equal(db.tables.actions_log.length, 0);
  });

  it("si la petición es ambigua, devuelve la pregunta y no crea nada", async () => {
    llmReply = geminiOk({ reply: "", clarification: "¿En el móvil o en el PC?", actions: [] });
    const db = new FakeDb({ devices: [android, pc], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre chrome" });
    assert.equal(out.body.clarification, "¿En el móvil o en el PC?");
    assert.equal(db.tables.actions_log.length, 0);
  });
  it("tolera que el modelo envuelva el JSON en un bloque de código", async () => {
    llmReply = geminiOk("```json\n" + JSON.stringify(openWhatsapp) + "\n```");
    const db = new FakeDb({ devices: [android], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal((out.body.actions as unknown[]).length, 1);
  });
  it("si el modelo devuelve basura: 502 bad_plan, sin acciones", async () => {
    llmReply = geminiOk("Lo siento, no puedo ayudarte con eso.");
    const db = new FakeDb({ devices: [android], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal(out.status, 502);
    assert.equal(out.body.code, "bad_plan");
    assert.equal(db.tables.actions_log.length, 0);
  });

  it("errores del proveedor: se traducen y jamás incluyen la clave", async () => {
    llmReply = () => new Response(JSON.stringify({ error: `API key ${SECRET} not valid` }), { status: 401 });
    const db = new FakeDb({ devices: [android], provider_configs: [gemini] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal(out.status, 502);
    assert.equal(out.body.code, "provider_auth");
    assert.ok(!JSON.stringify(out.body).includes(SECRET));
    llmReply = () => new Response("{}", { status: 429 });
    assert.equal((await runCommand(makeDeps(db), { message: "abre whatsapp" })).status, 429);
  });
  it("OpenRouter sin modelo: pide elegirlo (400) sin llamar a nadie; 'custom' no soportado", async () => {
    const db = new FakeDb({ devices: [android], provider_configs: [{ ...gemini, provider: "openrouter", model: null }] });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp" });
    assert.equal(out.status, 400);
    assert.equal(out.body.code, "no_model");
    const db2 = new FakeDb({ devices: [android], provider_configs: [{ ...gemini, provider: "custom" }] });
    assert.equal((await runCommand(makeDeps(db2), { message: "hola" })).body.code, "provider_unsupported");
    assert.equal(llmCalls.length, 0);
  });
  it("provider_id elige una clave concreta; la clave ilegible da 500 genérico", async () => {
    llmReply = geminiOk(openWhatsapp);
    const other = { ...gemini, id: "cfg-otro", provider: "anthropic", is_default: false, created_at: "2026-09-02T00:00:00Z" };
    const db = new FakeDb({ devices: [android], provider_configs: [gemini, other] });
    llmReply = () => new Response(JSON.stringify({ content: [{ type: "text", text: JSON.stringify(openWhatsapp) }] }), { status: 200 });
    const out = await runCommand(makeDeps(db), { message: "abre whatsapp", providerId: "cfg-otro" });
    assert.equal(out.body.provider, "anthropic");
    const noKey = await runCommand({ ...makeDeps(db), getProviderKey: async () => null }, { message: "abre whatsapp" });
    assert.equal(noKey.status, 500);
    assert.equal(noKey.body.code, "key_unavailable");
  });
});

describe("createAction — el camino único", () => {
  const act = (device_id: string, action = "OPEN_APP") => ({ action: action as "OPEN_APP", device_id, target: "x", params: {} });
  it("404 si no existe o no es del usuario; 409 si nunca se vinculó", async () => {
    const db = new FakeDb({ devices: [android, tablet] });
    assert.equal((await createAction(db.asClient(), "u1", act("nope"))).ok, false);
    const r = await createAction(db.asClient(), "u1", act("dev-tablet"));
    assert.ok(!r.ok && r.status === 409);
  });
  it("dispositivo sin capacidades anunciadas (aún desconocidas): se acepta", async () => {
    const db = new FakeDb({ devices: [{ ...android, capabilities: [] }] });
    const r = await createAction(db.asClient(), "u1", act("dev-android", "SHUTDOWN_DEVICE"));
    assert.ok(r.ok && r.log.status === "awaiting_confirmation");
  });
});
