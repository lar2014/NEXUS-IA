import { randomUUID } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "../../src/lib/database.types";

type Row = Record<string, unknown>;
type Result = { data: unknown; error: { message: string } | null };

/** Base de datos en memoria con SOLO las operaciones que usan actionsService y commandService. */
export class FakeDb {
  tables: Record<string, Row[]>;
  constructor(seed: Record<string, Row[]> = {}) {
    this.tables = { devices: [], provider_configs: [], actions_log: [], ...seed };
  }
  from(table: string): Query { return new Query(this, table); }
  asClient(): SupabaseClient<Database> { return this as unknown as SupabaseClient<Database>; }
}

class Query implements PromiseLike<Result> {
  private filters: Array<(r: Row) => boolean> = [];
  private orders: Array<{ col: string; asc: boolean }> = [];
  private max: number | undefined;
  private op: "select" | "insert" = "select";
  private payload: Row = {};

  constructor(private db: FakeDb, private table: string) {}

  select(_cols?: string): this { return this; }
  insert(p: Row): this { this.op = "insert"; this.payload = p; return this; }
  eq(col: string, val: unknown): this { this.filters.push((r) => r[col] === val); return this; }
  order(col: string, opts: { ascending?: boolean } = {}): this { this.orders.push({ col, asc: opts.ascending !== false }); return this; }
  limit(n: number): this { this.max = n; return this; }

  maybeSingle(): Promise<Result> { return this.run().then((r) => ({ data: (r.data as Row[] | null)?.[0] ?? null, error: r.error })); }
  single(): Promise<Result> {
    return this.run().then((r) => {
      const row = (r.data as Row[] | null)?.[0];
      return row ? { data: row, error: null } : { data: null, error: r.error ?? { message: "no rows" } };
    });
  }
  then<A, B>(ok?: ((v: Result) => A | PromiseLike<A>) | null, bad?: ((e: unknown) => B | PromiseLike<B>) | null): PromiseLike<A | B> {
    return this.run().then(ok, bad);
  }

  private async run(): Promise<Result> {
    const rows = this.db.tables[this.table] ?? (this.db.tables[this.table] = []);
    if (this.op === "insert") {
      const row: Row = { id: randomUUID(), created_at: new Date().toISOString(), delivered_at: null, executed_at: null, result: null, ...this.payload };
      rows.push(row);
      return { data: [row], error: null };
    }
    let out = rows.filter((r) => this.filters.every((f) => f(r)));
    for (const { col, asc } of [...this.orders].reverse()) {
      out = [...out].sort((a, b) => {
        const x = a[col] as string | boolean | number; const y = b[col] as string | boolean | number;
        return x === y ? 0 : (x > y ? 1 : -1) * (asc ? 1 : -1);
      });
    }
    if (this.max !== undefined) out = out.slice(0, this.max);
    return { data: out, error: null };
  }
}
