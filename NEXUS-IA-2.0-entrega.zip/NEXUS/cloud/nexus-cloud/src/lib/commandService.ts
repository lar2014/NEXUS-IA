import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "./database.types";
import { createAction } from "./actionsService";
import { BrainParseError, MAX_MESSAGE_CHARS, buildSystemPrompt, parsePlan, type DeviceInfo } from "./brain";
import { isOnline } from "./presence";
import { ProviderError, getAdapter, type ProviderErrorKind } from "./providers";

export interface CommandDeps {
  /** Cliente "como usuario": RLS aplica. Nunca el de servicio. */
  db: SupabaseClient<Database>;
  userId: string;
  /** Lee la clave descifrada. Solo el backend puede; nunca sale en ninguna respuesta. */
  getProviderKey: (configId: string) => Promise<string | null>;
  now?: () => number;
}

export interface CommandOutcome {
  status: number;
  body: Record<string, unknown>;
}

const HTTP_FOR_KIND: Record<ProviderErrorKind, number> = {
  auth: 502, model: 502, rate: 429, upstream: 502, network: 502, timeout: 504, empty: 502, unsupported: 400,
};

const LLM_TIMEOUT_MS = 22_000;

/**
 * El "cerebro": frase en lenguaje natural -> acciones estructuradas encoladas.
 *
 *   mensaje -> IA del usuario (su propia clave) -> JSON -> validación estricta
 *           -> createAction() (mismas comprobaciones y permisos que a mano)
 *
 * La IA solo PROPONE. Quien decide es createAction(): dispositivo del usuario,
 * capacidad, y permiso (que puede exigir aprobación o bloquear). Ningún camino
 * lleva de "lo que dijo el modelo" a "ejecutado" sin pasar por ahí.
 */
export async function runCommand(
  deps: CommandDeps,
  input: { message: unknown; providerId?: unknown },
): Promise<CommandOutcome> {
  const fail = (status: number, error: string, code: string, extra: Record<string, unknown> = {}): CommandOutcome =>
    ({ status, body: { error, code, ...extra } });

  const message = typeof input.message === "string" ? input.message.trim() : "";
  if (!message) return fail(400, "escribe qué quieres que haga Nexus", "empty_message");
  if (message.length > MAX_MESSAGE_CHARS) return fail(400, `el mensaje es demasiado largo (máximo ${MAX_MESSAGE_CHARS} caracteres)`, "message_too_long");

  // 1) Dispositivos ya vinculados del usuario
  const { data: rows, error: devErr } = await deps.db
    .from("devices")
    .select("id, name, type, capabilities, connected, last_seen, pairing_code");
  if (devErr) return fail(500, devErr.message, "db_error");

  const now = deps.now ? deps.now() : Date.now();
  const devices: DeviceInfo[] = (rows ?? [])
    .filter((d) => d.pairing_code === null)
    .map((d) => ({
      id: d.id,
      name: d.name,
      type: d.type,
      capabilities: Array.isArray(d.capabilities) ? d.capabilities.filter((c): c is string => typeof c === "string") : [],
      online: isOnline(d, now),
    }));
  if (!devices.length) {
    return { status: 200, body: { reply: "Todavía no tienes ningún dispositivo vinculado. Vincula uno primero y podré ayudarte.", clarification: null, actions: [], warnings: [] } };
  }

  // 2) Proveedor de IA del usuario
  let q = deps.db.from("provider_configs").select("id, provider, model, is_default, created_at");
  if (typeof input.providerId === "string" && input.providerId) q = q.eq("id", input.providerId);
  const { data: configs, error: cfgErr } = await q
    .order("is_default", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(1);
  if (cfgErr) return fail(500, cfgErr.message, "db_error");
  const config = configs?.[0];
  if (!config) return fail(409, "Guarda primero una clave de IA en «Proveedores de IA» para que Nexus pueda entenderte.", "no_provider");

  let adapter;
  try {
    adapter = getAdapter(config.provider);
  } catch (e) {
    const pe = e as ProviderError;
    return fail(HTTP_FOR_KIND[pe.kind] ?? 400, pe.message, `provider_${pe.kind}`);
  }
  const model = (config.model && config.model.trim()) || adapter.defaultModel;
  if (!model) return fail(400, `Para ${adapter.id} tienes que indicar el modelo (p. ej. «anthropic/claude-haiku-4.5» en OpenRouter). Vuelve a guardar la clave con un modelo.`, "no_model");

  // 3) Clave (solo el servidor la ve)
  let apiKey: string | null;
  try {
    apiKey = await deps.getProviderKey(config.id);
  } catch {
    return fail(500, "no se pudo leer la clave guardada", "key_unavailable");
  }
  if (!apiKey) return fail(500, "no se pudo leer la clave guardada", "key_unavailable");

  // 4) Preguntar a la IA
  let raw: string;
  try {
    raw = await adapter.complete({ system: buildSystemPrompt(devices), user: message, model, apiKey, timeoutMs: LLM_TIMEOUT_MS });
  } catch (e) {
    if (e instanceof ProviderError) return fail(HTTP_FOR_KIND[e.kind], e.message, `provider_${e.kind}`, { provider: adapter.id, model });
    return fail(502, "fallo inesperado al consultar a la IA", "provider_unknown");
  }

  // 5) Validar el plan (la salida del modelo no es de fiar)
  let plan;
  try {
    plan = parsePlan(raw, devices);
  } catch (e) {
    if (e instanceof BrainParseError) return fail(502, "La IA no devolvió un plan que pueda usar. Prueba a reformularlo.", "bad_plan", { preview: e.raw.slice(0, 300), provider: adapter.id, model });
    throw e;
  }

  // 6) Crear las acciones por el camino único (permisos incluidos)
  const results: Array<Record<string, unknown>> = [];
  for (const action of plan.actions) {
    const created = await createAction(deps.db, deps.userId, action);
    const device = devices.find((d) => d.id === action.device_id);
    results.push(created.ok
      ? { action: action.action, device_id: action.device_id, device_name: created.deviceName, target: action.target, status: created.log.status, action_id: created.log.id }
      : { action: action.action, device_id: action.device_id, device_name: device?.name ?? "", target: action.target, error: created.error, http_status: created.status });
  }

  return {
    status: 200,
    body: { reply: plan.reply, clarification: plan.clarification, actions: results, warnings: plan.warnings, provider: adapter.id, model },
  };
}
