import { anthropic } from "./anthropic";
import { gemini } from "./gemini";
import { openai, openrouter } from "./openaiCompatible";
import { ProviderError, type LlmAdapter } from "./types";

export * from "./types";

const ADAPTERS: Record<string, LlmAdapter> = { gemini, anthropic, openai, openrouter };

export const PROVIDER_DEFAULT_MODELS: Record<string, string | null> = Object.fromEntries(
  Object.values(ADAPTERS).map((a) => [a.id, a.defaultModel]),
);

/** "custom" existe en el esquema pero necesita una URL base que todavía no se guarda. */
export function getAdapter(provider: string): LlmAdapter {
  const adapter = ADAPTERS[provider];
  if (!adapter) {
    throw new ProviderError(
      provider === "custom"
        ? "el proveedor «Otro» todavía no está soportado (haría falta guardar también su URL base)"
        : `proveedor desconocido: ${provider}`,
      "unsupported",
    );
  }
  return adapter;
}
