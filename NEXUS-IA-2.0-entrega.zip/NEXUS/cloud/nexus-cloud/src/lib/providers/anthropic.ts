import { postJson } from "./http";
import { ProviderError, type LlmAdapter, type LlmRequest } from "./types";

export const anthropic: LlmAdapter = {
  id: "anthropic",
  // Modelo pequeño y rápido: interpretar una orden corta no necesita uno grande.
  defaultModel: "claude-haiku-4-5-20251001",
  async complete(req: LlmRequest): Promise<string> {
    const data = (await postJson(
      "https://api.anthropic.com/v1/messages",
      { "x-api-key": req.apiKey, "anthropic-version": "2023-06-01" },
      {
        model: req.model,
        max_tokens: 1024,
        temperature: 0,
        system: req.system,
        messages: [{ role: "user", content: req.user }],
      },
      { timeoutMs: req.timeoutMs, secrets: [req.apiKey] },
    )) as { content?: Array<{ type?: string; text?: string }> };

    const text = data.content?.filter((c) => c.type === "text").map((c) => c.text ?? "").join("") ?? "";
    if (!text.trim()) throw new ProviderError("Anthropic devolvió una respuesta vacía", "empty");
    return text;
  },
};
