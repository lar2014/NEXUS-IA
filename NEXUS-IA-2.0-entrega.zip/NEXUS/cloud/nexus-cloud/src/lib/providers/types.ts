export type ProviderErrorKind = "auth" | "model" | "rate" | "upstream" | "network" | "timeout" | "empty" | "unsupported";

export class ProviderError extends Error {
  constructor(message: string, public readonly kind: ProviderErrorKind, public readonly status?: number) {
    super(message);
    this.name = "ProviderError";
  }
}

export interface LlmRequest {
  system: string;
  user: string;
  model: string;
  apiKey: string;
  timeoutMs: number;
}

export interface LlmAdapter {
  readonly id: string;
  /** null = no hay un modelo por defecto razonable: el usuario tiene que elegirlo. */
  readonly defaultModel: string | null;
  /** Devuelve el TEXTO de la respuesta del modelo (que debe ser un objeto JSON). */
  complete(req: LlmRequest): Promise<string>;
}
