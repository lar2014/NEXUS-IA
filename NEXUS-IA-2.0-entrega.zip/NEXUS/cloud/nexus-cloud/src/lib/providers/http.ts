import { ProviderError } from "./types";

/**
 * POST JSON con tiempo máximo y errores clasificados. Nunca deja escapar la
 * clave: cualquier mensaje que vaya a salir hacia el usuario pasa por redact().
 */
export async function postJson(
  url: string,
  headers: Record<string, string>,
  body: unknown,
  opts: { timeoutMs: number; secrets: string[] },
): Promise<unknown> {
  const redact = (text: string): string => {
    let out = text;
    for (const s of opts.secrets) if (s) out = out.split(s).join("***");
    return out.length > 400 ? `${out.slice(0, 400)}…` : out;
  };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs);
  let res: Response;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    if (controller.signal.aborted) {
      throw new ProviderError(`el proveedor no respondió en ${Math.round(opts.timeoutMs / 1000)} s`, "timeout");
    }
    throw new ProviderError(`no se pudo conectar con el proveedor: ${redact(err instanceof Error ? err.message : String(err))}`, "network");
  } finally {
    clearTimeout(timer);
  }

  const text = await res.text();
  if (!res.ok) {
    const detail = redact(text);
    if (res.status === 401 || res.status === 403) {
      throw new ProviderError(`el proveedor rechazó la clave (${res.status}). Revisa que sea válida y tenga permiso. ${detail}`, "auth", res.status);
    }
    if (res.status === 404) {
      throw new ProviderError(`el proveedor no encuentra ese modelo o endpoint (404). Revisa el nombre del modelo. ${detail}`, "model", 404);
    }
    if (res.status === 429) {
      throw new ProviderError(`el proveedor limita las peticiones o te has quedado sin cuota (429). ${detail}`, "rate", 429);
    }
    throw new ProviderError(`error del proveedor (${res.status}): ${detail}`, "upstream", res.status);
  }

  try {
    return JSON.parse(text);
  } catch {
    throw new ProviderError("el proveedor devolvió algo que no es JSON", "upstream", res.status);
  }
}
