import { postJson } from "./http";
import { ProviderError, type LlmAdapter, type LlmRequest } from "./types";

export const gemini: LlmAdapter = {
  id: "gemini",
  defaultModel: "gemini-2.5-flash",
  async complete(req: LlmRequest): Promise<string> {
    // La clave va en cabecera (x-goog-api-key), NO en la URL: así no acaba en logs de acceso.
    const data = (await postJson(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(req.model)}:generateContent`,
      { "x-goog-api-key": req.apiKey },
      {
        systemInstruction: { parts: [{ text: req.system }] },
        contents: [{ role: "user", parts: [{ text: req.user }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0 },
      },
      { timeoutMs: req.timeoutMs, secrets: [req.apiKey] },
    )) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };

    const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
    if (!text.trim()) throw new ProviderError("Gemini devolvió una respuesta vacía (puede haberla bloqueado un filtro)", "empty");
    return text;
  },
};
