import { postJson } from "./http";
import { ProviderError, type LlmAdapter, type LlmRequest } from "./types";

/** OpenAI y OpenRouter hablan el mismo protocolo (chat/completions); solo cambian URL y modelo. */
function make(id: string, baseUrl: string, defaultModel: string | null): LlmAdapter {
  return {
    id,
    defaultModel,
    async complete(req: LlmRequest): Promise<string> {
      // Sin "temperature": algunos modelos nuevos solo aceptan el valor por defecto y rechazan el resto.
      const data = (await postJson(
        `${baseUrl}/chat/completions`,
        { Authorization: `Bearer ${req.apiKey}` },
        {
          model: req.model,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: req.system },
            { role: "user", content: req.user },
          ],
        },
        { timeoutMs: req.timeoutMs, secrets: [req.apiKey] },
      )) as { choices?: Array<{ message?: { content?: string | null } }> };

      const text = data.choices?.[0]?.message?.content ?? "";
      if (!text.trim()) throw new ProviderError(`${id} devolvió una respuesta vacía`, "empty");
      return text;
    },
  };
}

export const openai = make("openai", "https://api.openai.com/v1", "gpt-4o-mini");
// OpenRouter da acceso a cientos de modelos con nombres tipo "proveedor/modelo":
// no hay un valor por defecto sensato, así que se obliga a elegirlo.
export const openrouter = make("openrouter", "https://openrouter.ai/api/v1", null);
