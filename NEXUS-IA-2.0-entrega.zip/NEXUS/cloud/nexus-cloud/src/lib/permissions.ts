import type { ActionType } from "./actionsSchema";

export type PermissionLevel = "PERMITIDO" | "REQUIERE_CONFIRMACION" | "BLOQUEADO";
export const PERMISSION_LEVELS: readonly PermissionLevel[] = ["PERMITIDO", "REQUIERE_CONFIRMACION", "BLOQUEADO"];

/**
 * Política por defecto cuando el usuario NO ha fijado un permiso explícito para
 * un dispositivo (spec §4). Criterio: lo que abre, busca o cambia el volumen es
 * reversible y de bajo riesgo -> PERMITIDO. Lo que envía en nombre del usuario,
 * escribe archivos, lee información privada, captura la pantalla o afecta al
 * propio dispositivo (bloquear/apagar) -> REQUIERE_CONFIRMACION.
 *
 * Esto importa sobre todo porque las acciones pueden nacer de un modelo de IA
 * que interpreta texto libre: una frase mal entendida no debe poder apagar un
 * PC ni mandar un mensaje sin que una persona lo apruebe. El usuario puede
 * relajarlo por dispositivo desde el panel (PERMITIDO explícito).
 */
export const DEFAULT_PERMISSIONS: Record<ActionType, PermissionLevel> = {
  OPEN_APP: "PERMITIDO",
  OPEN_URL: "PERMITIDO",
  OPEN_FILE: "PERMITIDO",
  SEARCH_WEB: "PERMITIDO",
  SET_VOLUME: "PERMITIDO",
  CONTROL_MEDIA: "PERMITIDO",
  SEND_MESSAGE: "REQUIERE_CONFIRMACION",
  CREATE_FILE: "REQUIERE_CONFIRMACION",
  CREATE_FOLDER: "REQUIERE_CONFIRMACION",
  TAKE_SCREENSHOT: "REQUIERE_CONFIRMACION",
  READ_NOTIFICATION: "REQUIERE_CONFIRMACION",
  LOCK_DEVICE: "REQUIERE_CONFIRMACION",
  SHUTDOWN_DEVICE: "REQUIERE_CONFIRMACION",
};

export function isPermissionLevel(v: unknown): v is PermissionLevel {
  return typeof v === "string" && (PERMISSION_LEVELS as readonly string[]).includes(v);
}

/** El permiso explícito del dispositivo manda; si no hay, el de por defecto. */
export function effectivePermission(explicit: unknown, action: ActionType): PermissionLevel {
  return isPermissionLevel(explicit) ? explicit : DEFAULT_PERMISSIONS[action];
}

export type InitialStatus = "pending" | "awaiting_confirmation" | "blocked";
export function initialStatusFor(level: PermissionLevel): InitialStatus {
  return level === "BLOQUEADO" ? "blocked" : level === "REQUIERE_CONFIRMACION" ? "awaiting_confirmation" : "pending";
}

/** Una acción que nadie ha recogido/aprobado en este tiempo deja de ser válida. */
export const ACTION_TTL_MS = 60 * 60 * 1000;
