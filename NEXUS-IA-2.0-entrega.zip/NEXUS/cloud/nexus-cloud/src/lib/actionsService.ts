import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, Json } from "./database.types";
import type { Action } from "./actionsSchema";
import { effectivePermission, initialStatusFor } from "./permissions";

type ActionRow = Database["public"]["Tables"]["actions_log"]["Row"];

export type CreateActionResult =
  | { ok: true; log: ActionRow; deviceName: string }
  | { ok: false; status: number; error: string; extra?: Record<string, unknown> };

/**
 * ÚNICO sitio donde nace una acción, venga del panel (a mano) o del cerebro
 * (interpretada por una IA). Que haya un solo camino garantiza que la IA no
 * pueda saltarse ninguna comprobación que sí se le aplica a un humano:
 * dispositivo del propio usuario, ya vinculado, con la capacidad, y permiso.
 *
 * `db` DEBE ser el cliente "como usuario" (supabaseForUser): así RLS impide
 * tocar dispositivos ajenos aunque hubiera un fallo aquí.
 */
export async function createAction(
  db: SupabaseClient<Database>,
  userId: string,
  action: Action,
): Promise<CreateActionResult> {
  const { data: device, error: deviceError } = await db
    .from("devices")
    .select("id, name, permissions, capabilities, pairing_code")
    .eq("id", action.device_id)
    .maybeSingle();

  if (deviceError) return { ok: false, status: 500, error: deviceError.message };
  // "No encontrado" cubre "no existe" y "no es tuyo" sin distinguirlos, adrede.
  if (!device) return { ok: false, status: 404, error: "dispositivo no encontrado o no es tuyo" };

  if (device.pairing_code !== null) {
    return { ok: false, status: 409, error: "ese dispositivo aún no se ha vinculado (nadie ha introducido su código)" };
  }

  if (Array.isArray(device.capabilities) && device.capabilities.length > 0
      && !device.capabilities.includes(action.action)) {
    return {
      ok: false, status: 422,
      error: `el dispositivo «${device.name}» no soporta ${action.action}`,
      extra: { supported: device.capabilities },
    };
  }

  const perms = (device.permissions && typeof device.permissions === "object" && !Array.isArray(device.permissions)
    ? device.permissions : {}) as Record<string, unknown>;
  const level = effectivePermission(perms[action.action], action.action);
  const status = initialStatusFor(level);

  const { data: logged, error: insertError } = await db
    .from("actions_log")
    .insert({
      user_id: userId,
      device_id: action.device_id,
      action_type: action.action,
      target: action.target,
      params: action.params as Json, // ya validado como objeto JSON por validateAction()
      status,
      result: status === "blocked" ? "Bloqueada por el permiso de este dispositivo" : null,
    })
    .select("*")
    .single();

  if (insertError) return { ok: false, status: 500, error: insertError.message };
  return { ok: true, log: logged, deviceName: device.name };
}
