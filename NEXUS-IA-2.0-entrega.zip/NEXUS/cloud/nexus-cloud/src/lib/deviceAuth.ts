import type { VercelRequest } from "@vercel/node";
import crypto from "node:crypto";
import { supabaseAdmin } from "./supabaseAdmin";

export interface AuthedDevice {
  deviceId: string;
  userId: string;
}

/**
 * Autentica un AGENT (no un usuario humano) por sus dos cabeceras propias:
 * X-Device-Id y X-Device-Secret. El Agent recibió ese secreto UNA vez, al
 * reclamar su código de vinculación (api/devices/claim.ts) — aquí solo se
 * compara su hash, el valor en claro no se guarda nunca en la base de datos.
 *
 * Usa supabaseAdmin() (bypassa RLS) porque un Agent no tiene un JWT de
 * Supabase Auth — no es un "usuario" para el sistema de autenticación,
 * es un dispositivo. Por eso cada función que llama a getAuthedDevice()
 * debe seguir filtrando manualmente por device_id en sus queries, igual
 * que ya hace api/devices/claim.ts.
 */
export async function getAuthedDevice(req: VercelRequest): Promise<AuthedDevice | null> {
  const deviceId = req.headers["x-device-id"];
  const deviceSecret = req.headers["x-device-secret"];
  if (typeof deviceId !== "string" || typeof deviceSecret !== "string" || !deviceId || !deviceSecret) {
    return null;
  }

  const { data: device, error } = await supabaseAdmin()
    .from("devices")
    .select("id, user_id, device_secret_hash")
    .eq("id", deviceId)
    .maybeSingle();

  if (error || !device || !device.device_secret_hash) return null;

  const providedHash = crypto.createHash("sha256").update(deviceSecret).digest("hex");
  const a = Buffer.from(providedHash, "hex");
  const b = Buffer.from(device.device_secret_hash, "hex");
  // Comparación en tiempo constante — evita que alguien adivine el secreto
  // midiendo cuánto tarda la respuesta según cuántos caracteres acierta.
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  return { deviceId: device.id, userId: device.user_id };
}
