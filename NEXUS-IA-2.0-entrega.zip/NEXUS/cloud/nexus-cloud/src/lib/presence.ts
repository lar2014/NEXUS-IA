// Un Agent se considera "online" si su último latido fue hace menos de esto.
// 20 min cubre el sondeo de 15 min del Agent Android (mínimo de Android); el
// Agent de PC hace sondeo largo continuo y cabe de sobra.
export const ONLINE_WINDOW_MS = 20 * 60 * 1000;

export function isOnline(d: { connected: boolean; last_seen: string | null }, now: number = Date.now()): boolean {
  return d.connected && d.last_seen !== null && now - new Date(d.last_seen).getTime() < ONLINE_WINDOW_MS;
}
