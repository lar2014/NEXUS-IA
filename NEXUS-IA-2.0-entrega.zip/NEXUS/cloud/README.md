# cloud/ — Nexus Cloud

Backend TypeScript (Vercel Functions) + base de datos Supabase. Fuera de `cloud/` está el
Agent de Windows; `agent-android/` es el Agent Android.

## Qué hay

| Pieza | Estado |
|---|---|
| Supabase `nexus-cloud` (`ipdgezppzuwvrgzfwwpu`, eu-west-1) | Desplegado y verificado: esquema, RLS, Vault, bucket `user-files`, estados de acción nuevos, `model` por proveedor |
| Backend `cloud/nexus-cloud/api/*` | 42 pruebas + `tsc` limpio. **Hay que redesplegar** (ver abajo) |
| Panel web `cloud/nexus-cloud/public/` | Login, **«Habla con Nexus»**, dispositivos, permisos, vincular, acciones a mano, aprobar/rechazar, claves de IA con modelo y borrado. 39 comprobaciones en jsdom |
| **Cerebro** `POST /api/command` | Frase -> IA del usuario -> acciones validadas -> cola. Probado con IA simulada; **no con una IA real** (aquí no hay clave) |
| **Agent de Windows <-> nube** | `nexus_core/cloud_link.py` (ver `../CLOUD_LINK.md`). 23 pruebas contra un servidor HTTP real |
| **Entrega casi instantánea** | Sondeo largo para el PC (~1-2 s). Android sigue a 15 min |
| Agent Android | Escrito, **no compilado** (`../agent-android/ANDROID_AGENT.md`) |

## Flujo completo

```
"abre Chrome en mi PC"  ──>  POST /api/command
   IA del usuario (Gemini/Claude/OpenAI/OpenRouter, su clave desde Vault)
   ──> JSON ──> parsePlan() [salida NO fiable: se descarta lo que no encaje]
   ──> createAction() [dispositivo del usuario · capacidad · permiso]
   ──> actions_log: pending | awaiting_confirmation | blocked
   ──> (si pide aprobación) el usuario aprueba en el panel  ──> pending
   ──> el Agent lo recoge (delivered) ──> ToolManager.run() ──> executed | failed | awaiting_device
```

## Endpoints

| Ruta | Quién | Para qué |
|---|---|---|
| `POST /api/command` | usuario | **El cerebro.** `{message, provider_id?}` |
| `GET /api/health` | cualquiera | Conectividad real con Supabase |
| `GET /api/config` | panel | URL + clave **publicable** + listas (acciones, permisos por defecto, modelos) |
| `GET /api/devices` · `PATCH/DELETE /api/devices/[id]` | usuario | Listar (con `online`) / permisos / desvincular |
| `POST /api/devices/pairing` | usuario | Código de vinculación |
| `POST /api/devices/claim` | Agent | Canjea el código (atómico) |
| `POST /api/devices/report` | Agent | Latido + capacidades |
| `GET /api/devices/pending-actions[?wait=N]` | Agent | Recoge acciones. `wait` (máx. 25) = sondeo largo |
| `GET/POST /api/actions` | usuario | Historial / acción a mano |
| `POST /api/actions/confirm` | usuario | Aprobar/rechazar (no vale si tiene >1 h) |
| `POST /api/actions/report` | Agent | Resultado: `executed`/`failed`/`awaiting_device` |
| `GET/POST/DELETE /api/providers` | usuario | Claves de IA con modelo (cifradas; borrables) |
| `GET/POST/DELETE /api/memory` | usuario | Memoria (sin uso desde el cerebro todavía) |

**Estados de una acción:** `pending` -> `delivered` -> `executed` | `failed` ·
`awaiting_confirmation` (aprobación del usuario) · `awaiting_device` (confirmación local en el PC) · `blocked`.

## Desplegar (lo tienes que hacer tú: la conexión de Vercel de la sesión no puede actualizar el proyecto)

```bash
cd cloud/nexus-cloud
npm install -g vercel     # una vez
vercel login              # una vez
vercel link               # una vez: elige "nexus-cloud"
vercel --prod
```
Tras desplegar: `/` debe mostrar el login. Si da 404, avísame.

## Supabase Auth (dos ajustes manuales, imprescindibles)

Dashboard -> `nexus-cloud` -> **Authentication**:
1. **URL Configuration -> Site URL** = `https://nexus-cloud-estud-ia.vercel.app` (por defecto es `localhost:3000`).
2. **Email -> Confirm email**: desactívalo para probar tú solo; reactívalo al abrirlo a más gente.

## Riesgos que NO he podido verificar (léelos)

1. **Coste del sondeo largo.** Cada PC vinculado mantiene una función de Vercel abierta casi
   24 h al día (25 s por petición) y hace ~17 consultas a Supabase por sondeo. En el plan
   Hobby puede consumir la cuota gratuita de duración de funciones. **Mira Vercel -> Usage
   unos días después de vincular el PC.** Si molesta: subir el intervalo (`POLL_WAIT_S`) o
   pasar a Supabase Realtime (siguiente paso posible).
2. **Límite de duración.** Configuré `maxDuration: 30`. Si Vercel lo recortara (plan/ajustes),
   el sondeo daría timeouts y el log de NEXUS mostraría «sin conexión» de forma intermitente.
3. **Modelos de IA reales.** Probé el parser con salidas simuladas y toleré las variantes
   habituales (bloques ```json, texto alrededor). Un modelo real puede comportarse distinto;
   el primer uso real puede pedir ajustar el prompt (`src/lib/brain.ts`). Los nombres de modelo
   por defecto pueden retirarse: el panel deja elegir el modelo.

## Pendientes conocidos

1. **Sin memoria de conversación ni del usuario**: cada frase se interpreta sola («y ahora
   ábrelo en el otro» no funciona) y el cerebro no lee `memory_entries` todavía.
2. **Android en 15 min** (FCM necesita un proyecto Firebase tuyo).
3. **Nada devuelve datos al usuario** (capturas, notificaciones leídas): solo hay órdenes de ida.
4. `/api/health` público con detalle del error; sin límite de intentos al canjear códigos.
5. `connected` nunca vuelve a `false` (se deduce del último latido, ventana de 20 min).
6. Proveedor «Otro» (URL base propia) no soportado. Sin interfaz para la memoria.
