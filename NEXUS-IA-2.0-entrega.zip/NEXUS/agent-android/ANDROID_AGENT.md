# ANDROID_AGENT.md — Nexus Agent para Android

## Antes de nada: por qué esto NO es "lo mismo que en Windows"

En `nexus_core/actions_schema.py` (el Agent de Windows), 12 de los 13
`ACTION_TYPES` ya tenían un tool real detrás. En Android, la situación es
distinta **por diseño del sistema operativo**, no por falta de esfuerzo:
Android restringe deliberadamente lo que una app puede hacerle a otras apps
o al propio dispositivo, mucho más que Windows a un proceso de escritorio.

| ACTION_TYPE | ¿Se puede en Android? | Cómo, y con qué coste |
|---|---|---|
| `OPEN_APP` | **Sí, pero solo con «Mostrar sobre otras apps» concedido** (o con la app en pantalla) | `PackageManager.getLaunchIntentForPackage()` + `startActivity()`. Necesita el nombre de paquete exacto (`com.whatsapp`, no "whatsapp") y, desde Android 11, la declaración `<queries>` del manifiesto. Android 10+ bloquea `startActivity()` desde segundo plano en silencio — ver "Corrección importante" |
| `OPEN_URL` | **Sí, con la misma condición** | `Intent(ACTION_VIEW, uri)` + `startActivity()` — mismo bloqueo en segundo plano |
| `SEARCH_WEB` | **Sí, con la misma condición** | Mismo mecanismo que `OPEN_URL`, con una URL de búsqueda |
| `SET_VOLUME` | **Sí, sin permisos especiales, también en segundo plano** | `AudioManager.setStreamVolume()` — no abre ninguna pantalla, así que no le afecta el bloqueo |
| `CONTROL_MEDIA` | **Parcial, requiere un permiso especial concedido a mano** | Necesita acceso de "Notification Listener", que el usuario activa manualmente en Ajustes del sistema — Android no deja pedirlo por diálogo normal |
| `TAKE_SCREENSHOT` | **Parcial, con fricción real** | La API `MediaProjection` exige que el usuario confirme un diálogo de "esta app va a grabar tu pantalla" **cada vez que la app se reinicia** — no se puede automatizar sin ese aviso |
| `SEND_MESSAGE` | **Parcial y limitado** | SMS es factible (permiso `SEND_SMS`, viable en una app instalada manualmente, sin pasar por Play Store) — pero WhatsApp/Telegram no tienen una forma oficial de "enviar" sin que el usuario pulse el botón final; solo se puede abrir el chat con el texto ya escrito |
| `READ_NOTIFICATION` | **Parcial, mismo permiso que CONTROL_MEDIA** | Notification Listener, activación manual |
| `LOCK_DEVICE` | **Parcial, con fricción real** | Requiere que el usuario active la app como "Administrador del dispositivo" — Android muestra una pantalla de advertencia explícita, no es un permiso silencioso |
| `SHUTDOWN_DEVICE` | **No. De verdad no.** | Apagar el dispositivo por software solo lo puede hacer una app de sistema o con acceso root — ninguna app instalada normalmente puede hacerlo, y no hay forma de sortear esto sin modificar el propio Android |
| `OPEN_FILE` / `CREATE_FILE` / `CREATE_FOLDER` | **Sí, con Storage Access Framework** | Requiere que el usuario conceda acceso a una carpeta la primera vez (`ACTION_OPEN_DOCUMENT_TREE`) — no hay acceso libre al sistema de ficheros como en Windows desde Android 11 |

**Decisión para esta primera versión**: implemento de verdad
`OPEN_APP`, `OPEN_URL`, `SEARCH_WEB` y `SET_VOLUME`. El resto queda con un
manejador que responde honestamente "no soportado todavía" en vez de fingir
que funciona, siguiendo el mismo principio que ya aplicó
`nexus_core/actions_schema.py` para `READ_NOTIFICATION` en el Agent de Windows.

## Corrección importante (respecto a la primera versión de este documento)

La primera versión de esta tabla decía que `OPEN_APP`, `OPEN_URL` y
`SEARCH_WEB` funcionaban "sin permisos especiales". **Eso era incorrecto para
el caso que nos importa.** Desde Android 10, una app en segundo plano no puede
llamar a `startActivity()`: Android lo descarta sin error visible. Y el sondeo
periódico *siempre* se ejecuta en segundo plano. Consecuencias y qué se hizo:

1. **Permiso "Mostrar sobre otras apps"** (`SYSTEM_ALERT_WINDOW`): es la
   excepción que Android reconoce para poder abrir actividades desde segundo
   plano. Lo concede el usuario una vez, a mano; hay un botón en la pantalla
   principal de la app que abre la pantalla de Ajustes correcta.
2. **Ya no se miente sobre el resultado.** `ActionExecutor` comprueba antes de
   intentarlo si puede abrir actividades (permiso concedido o app en primer
   plano); si no, reporta `failed` con el motivo real, en vez de `executed`.
3. **`<queries>` en el manifiesto**: desde Android 11 una app no ve qué otras
   hay instaladas salvo que lo declare. Sin ello `getLaunchIntentForPackage`
   devolvía `null` aunque WhatsApp estuviera instalado.
4. **Sin verificar por mí**: Android 15 endureció más esta excepción (parece
   exigir además una ventana flotante visible). No lo he podido comprobar sin un
   dispositivo. Si en tu móvil abrir apps en segundo plano sigue fallando aun con
   el permiso concedido, es lo primero que hay que investigar. La alternativa
   robusta es mostrar una notificación con un botón «Abrir» (el toque del
   usuario sí está siempre permitido) — pendiente de implementar.
5. **Fabricantes con capas propias** (Xiaomi, Huawei, Samsung…) suelen añadir
   sus propios permisos de "ventanas emergentes en segundo plano" y de
   optimización de batería. Si el sondeo deja de correr, hay que excluir la app
   de la optimización de batería en los Ajustes del móvil.

## Arquitectura: Agent Android ↔ Nexus Cloud

```
[App Android]
   │ 1. Vinculación (una vez): el usuario introduce el código "7F4-K92"
   │    que generó /api/devices/pairing (con su sesión ya iniciada)
   ▼
POST /api/devices/claim  →  recibe device_id + device_secret (una sola vez)
   │
   │ 2. Guarda device_id + device_secret en EncryptedSharedPreferences
   │    (cifrado por el propio Android, ligado a este dispositivo)
   ▼
[WorkManager, cada 15 minutos (mínimo real de Android para trabajo periódico)]
   │ 3. POST /api/devices/report        (heartbeat: "sigo conectado")
   │ 4. GET  /api/devices/pending-actions  (¿hay algo que hacer?)
   │ 5. Por cada acción: ActionExecutor.execute(action)
   │ 6. POST /api/actions/report        (resultado: executed | failed)
```

No hay notificaciones push (no usa Firebase Cloud Messaging todavía) — es
**polling cada 15 minutos**, el intervalo mínimo que Android permite para
trabajo periódico estándar sin un servicio en primer plano persistente.
Esto es una limitación real y consciente: implementar FCM es una pieza más
(necesita una cuenta de Firebase, credenciales de servidor en Nexus Cloud)
que dejo fuera de esta primera versión para no bloquear la primera prueba
funcional — pero significa que, hoy, pedirle a NEXUS "abre WhatsApp en mi
móvil" puede tardar hasta 15 minutos en ejecutarse, no es instantáneo.

## Cómo vincular tu móvil (ya hay pantalla de login)

1. Abre el panel de Nexus Cloud en el navegador (`https://nexus-cloud-estud-ia.vercel.app`),
   crea tu cuenta o entra.
2. En **Dispositivos → Vincular un dispositivo nuevo**: nombre "Mi Android",
   tipo Android → **Generar código** (formato `XXX-XXX`, 10 min, un solo uso).
3. En la app Android, introduce el código y pulsa **Vincular**.
4. Pulsa **Conceder «Mostrar sobre otras apps»** y actívalo (ver arriba).
5. Desde el panel, **Enviar una acción** (p. ej. `OPEN_APP` → `whatsapp`) y en la
   app pulsa **Sincronizar ahora** para no esperar los 15 minutos del sondeo.

## Lo que falta para que esto sea un producto real

- Notificaciones push (FCM) en vez de sondeo cada 15 min.
- Notificación con botón «Abrir» como alternativa cuando Android bloquee el
  arranque desde segundo plano (ver punto 4 de la corrección).
- Los ACTION_TYPES marcados como "parcial", cada uno con su flujo de activación
  manual explicado dentro de la app.
- Icono propio de la app y firma de la APK para distribuirla fuera de "instalar
  el .apk a mano".
- La URL de Nexus Cloud está fija en `PollWorker.kt` (`BuildConfigValues`); en
  una versión real debería salir de la configuración de compilación.

## Nota (fase del cerebro): estados y sondeo

- Al pedir `pending-actions`, el servidor marca las acciones como **`delivered`** de
  forma atómica: si la app se cierra a mitad, esa acción **no se repite sola**.
- Una acción que lleva más de 1 hora esperando se descarta (`failed`, «Caducada»), así
  que si el móvil estuvo apagado toda la noche no ejecutará órdenes viejas al volver.
- Esta app sigue sondeando sin `?wait=` (respuesta inmediata) cada 15 min. El sondeo
  largo que usa el PC no encaja con WorkManager; para notificaciones casi instantáneas
  en Android hace falta FCM (Firebase), que necesita un proyecto de Firebase tuyo.
- No hace falta recompilar la app por los cambios de esta fase.
