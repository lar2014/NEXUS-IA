// NOTA: este proyecto NO se ha compilado en el entorno donde se generó —
// aquí no hay Android SDK ni Gradle con los plugins de Android disponibles
// para verificarlo. Está escrito siguiendo las APIs estables y documentadas
// de Android, pero antes de instalarlo en un dispositivo real, ábrelo en
// Android Studio y compílalo ahí primero — es el único sitio donde se
// puede verificar de verdad.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
