plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexus.agent"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nexus.agent"
        minSdk = 26          // Android 8.0 — mínimo razonable para WorkManager + EncryptedSharedPreferences sin parches
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-prototipo"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    // Cliente HTTP — el más estándar para llamadas REST en Android.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Trabajo en segundo plano periódico (el polling de acciones pendientes).
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4") // lifecycleScope en MainActivity

    // Almacenamiento cifrado del device_id/device_secret en el propio dispositivo.
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
