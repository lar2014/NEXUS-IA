package com.nexus.agent

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Única pantalla del prototipo: vincular con el código que genera el panel web
 * de Nexus Cloud, ver el estado, conceder el permiso de "Mostrar sobre otras
 * apps" y forzar una sincronización (para probar sin esperar 15 minutos).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var store: SecureStore
    private lateinit var statusText: TextView
    private lateinit var overlayText: TextView
    private lateinit var codeInput: EditText
    private lateinit var pairButton: Button
    private lateinit var syncButton: Button
    private lateinit var overlayButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = SecureStore(this)
        statusText = findViewById(R.id.statusText)
        overlayText = findViewById(R.id.overlayText)
        codeInput = findViewById(R.id.codeInput)
        pairButton = findViewById(R.id.pairButton)
        syncButton = findViewById(R.id.syncButton)
        overlayButton = findViewById(R.id.overlayButton)

        pairButton.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Introduce el código primero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pair(code)
        }

        syncButton.setOnClickListener {
            if (!store.isPaired()) {
                Toast.makeText(this, "Vincula el dispositivo primero", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            syncNow()
        }

        overlayButton.setOnClickListener {
            // Pantalla del sistema donde el usuario concede "Mostrar sobre otras apps".
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        if (store.isPaired()) schedulePolling()
    }

    // Al volver de los Ajustes del sistema se refresca el estado del permiso.
    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        statusText.text = if (store.isPaired()) {
            "Vinculado — device_id: ${store.deviceId}"
        } else {
            "Sin vincular. Genera un código en el panel web de Nexus Cloud e introdúcelo aquí."
        }
        overlayText.text = if (Settings.canDrawOverlays(this)) {
            "Abrir apps en segundo plano: PERMITIDO"
        } else {
            "Abrir apps en segundo plano: NO permitido. Sin esto, Android bloquea abrir apps " +
                "y webs cuando la app no está en pantalla."
        }
    }

    private fun pair(pairingCode: String) {
        pairButton.isEnabled = false
        lifecycleScope.launch {
            try {
                val client = NexusCloudClient(BuildConfigValues.CLOUD_BASE_URL)
                val result = withContext(Dispatchers.IO) {
                    client.claim(pairingCode, PollWorker.SUPPORTED_ACTION_TYPES)
                }
                store.deviceId = result.deviceId
                store.deviceSecret = result.deviceSecret
                refreshStatus()
                schedulePolling()
                syncNow() // primer latido ya, para que el panel lo vea online sin esperar
                Toast.makeText(this@MainActivity, "Vinculado correctamente", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Fallo al vincular: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                pairButton.isEnabled = true
            }
        }
    }

    private fun syncNow() {
        WorkManager.getInstance(applicationContext).enqueue(OneTimeWorkRequestBuilder<PollWorker>().build())
        Toast.makeText(this, "Sincronizando…", Toast.LENGTH_SHORT).show()
    }

    private fun schedulePolling() {
        // 15 minutos es el MÍNIMO que Android permite para trabajo periódico
        // estándar; además el modo Doze puede retrasarlo más con la pantalla apagada.
        val request = PeriodicWorkRequestBuilder<PollWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "nexus-agent-poll",
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }
}
