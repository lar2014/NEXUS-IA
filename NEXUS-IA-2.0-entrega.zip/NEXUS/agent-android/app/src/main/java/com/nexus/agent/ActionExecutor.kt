package com.nexus.agent

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings

/**
 * Implementa lo que Android permite de verdad: OPEN_APP, OPEN_URL, SEARCH_WEB,
 * SET_VOLUME. Todo lo demás devuelve "no soportado" en vez de fingir que
 * funciona (mismo principio que ACTION_TO_TOOL en el Agent de Windows).
 *
 * IMPORTANTE (ver ANDROID_AGENT.md, "Corrección importante"): abrir apps o URLs
 * es un startActivity(), y Android 10+ lo bloquea EN SILENCIO cuando lo hace una
 * app que está en segundo plano — que es siempre el caso del sondeo periódico.
 * Solo se permite si (a) la app tiene el permiso "Mostrar sobre otras apps", o
 * (b) está en primer plano (p. ej. al pulsar «Sincronizar ahora»). Aquí se
 * comprueba ANTES de intentarlo, para no informar de "ejecutada" algo que
 * Android en realidad ha descartado.
 */
class ActionExecutor(private val context: Context) {

    sealed class ExecutionResult {
        data class Success(val message: String) : ExecutionResult()
        data class Failure(val message: String) : ExecutionResult()

        companion object {
            fun unsupported(actionType: String): Failure = Failure(
                "'$actionType' no está soportado todavía en este Agent Android — " +
                "ver la tabla de viabilidad en ANDROID_AGENT.md."
            )
        }
    }

    // Nombres de paquete de apps comunes: OPEN_APP recibe un nombre en lenguaje
    // natural ("whatsapp") pero Android necesita el paquete exacto. Fuera de
    // esta lista se prueba el texto tal cual, por si ya era un paquete.
    private val knownPackages = mapOf(
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "youtube" to "com.google.android.youtube",
        "maps" to "com.google.android.apps.maps",
        "telegram" to "org.telegram.messenger",
        "spotify" to "com.spotify.music",
    )

    fun execute(actionType: String, target: String): ExecutionResult = when (actionType) {
        "OPEN_APP" -> guardedLaunch { openApp(target) }
        "OPEN_URL" -> guardedLaunch { openUrl(target) }
        "SEARCH_WEB" -> guardedLaunch { openUrl("https://www.google.com/search?q=" + Uri.encode(target)) }
        "SET_VOLUME" -> setVolume(target)
        else -> ExecutionResult.unsupported(actionType)
    }

    private fun guardedLaunch(launch: () -> ExecutionResult): ExecutionResult =
        if (canStartActivitiesNow()) launch() else ExecutionResult.Failure(BACKGROUND_BLOCKED_MESSAGE)

    private fun canStartActivitiesNow(): Boolean {
        if (Settings.canDrawOverlays(context)) return true
        val info = ActivityManager.RunningAppProcessInfo()
        ActivityManager.getMyMemoryState(info)
        return info.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
    }

    private fun openApp(target: String): ExecutionResult {
        val packageName = knownPackages[target.lowercase()] ?: target
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return ExecutionResult.Failure(
                "No se encontró la app '$target' (paquete probado: $packageName). " +
                "¿Está instalada? Si el nombre no está en la lista de conocidos, " +
                "hay que enviar el nombre de paquete exacto."
            )
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return ExecutionResult.Success("Abierta: $packageName")
    }

    private fun openUrl(url: String): ExecutionResult {
        val normalized = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ExecutionResult.Success("Abierta URL: $normalized")
    }

    private fun setVolume(target: String): ExecutionResult {
        val level = target.toIntOrNull()
            ?: return ExecutionResult.Failure("SET_VOLUME necesita un número (0-100) como destino, recibido: '$target'")

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val clamped = level.coerceIn(0, 100)
        val volumeIndex = (clamped / 100.0 * max).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volumeIndex, 0)
        return ExecutionResult.Success("Volumen puesto a $clamped% ($volumeIndex/$max)")
    }

    private companion object {
        const val BACKGROUND_BLOCKED_MESSAGE =
            "Android bloquea abrir apps desde segundo plano. Activa «Mostrar sobre otras apps» " +
            "para Nexus Agent (botón en su pantalla principal), o abre la app y pulsa «Sincronizar ahora»."
    }
}
