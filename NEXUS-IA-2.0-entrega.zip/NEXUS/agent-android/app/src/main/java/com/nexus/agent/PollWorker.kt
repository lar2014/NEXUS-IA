package com.nexus.agent

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Se ejecuta periódicamente (ver MainActivity.schedulePolling()) — cada 15
 * minutos como mínimo, que es el límite real que WorkManager impone para
 * trabajo periódico estándar (no se puede bajar de ahí sin un servicio en
 * primer plano persistente, fuera de alcance de este prototipo). Cada
 * ejecución: manda un latido, pide las acciones pendientes, las ejecuta con
 * ActionExecutor, y reporta el resultado.
 *
 * LIMITACIÓN CONOCIDA (ver ANDROID_AGENT.md): esto es polling, no push. Una
 * acción puede tardar hasta 15 minutos en llegar al móvil, no es
 * instantáneo como en el Agent de Windows con Gemini Live.
 */
class PollWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val store = SecureStore(applicationContext)
        val deviceId = store.deviceId
        val deviceSecret = store.deviceSecret
        if (deviceId == null || deviceSecret == null) {
            // Todavía no se ha vinculado ningún dispositivo — no es un
            // error, simplemente no hay nada que hacer hasta que el
            // usuario complete la vinculación desde MainActivity.
            return@withContext Result.success()
        }

        val client = NexusCloudClient(BuildConfigValues.CLOUD_BASE_URL)
        val executor = ActionExecutor(applicationContext)

        return@withContext try {
            client.reportHeartbeat(deviceId, deviceSecret, capabilities = SUPPORTED_ACTION_TYPES)

            val pending = client.fetchPendingActions(deviceId, deviceSecret)
            for (action in pending) {
                val outcome = executor.execute(action.actionType, action.target)
                when (outcome) {
                    is ActionExecutor.ExecutionResult.Success ->
                        client.reportActionResult(deviceId, deviceSecret, action.id, "executed", outcome.message)
                    is ActionExecutor.ExecutionResult.Failure ->
                        client.reportActionResult(deviceId, deviceSecret, action.id, "failed", outcome.message)
                }
            }
            Result.success()
        } catch (e: Exception) {
            // Un fallo de red no debe desprogramar el siguiente intento —
            // WorkManager reintenta según la política del propio trabajo.
            Result.retry()
        }
    }

    companion object {
        // Debe coincidir con capabilities_for() en el lado de Cloud/Agent
        // de Windows para los 4 tipos que este Agent Android sí implementa.
        val SUPPORTED_ACTION_TYPES = listOf("OPEN_APP", "OPEN_URL", "SEARCH_WEB", "SET_VOLUME")
    }
}

/**
 * La URL de Nexus Cloud NO debería quedar hardcodeada en un fichero de
 * código fuente en un proyecto real — esto es un valor de ejemplo para que
 * el prototipo arranque. En una versión real, debería venir de
 * BuildConfig (variantes de build) o de una pantalla de configuración.
 */
object BuildConfigValues {
    const val CLOUD_BASE_URL = "https://nexus-cloud-estud-ia.vercel.app"
}
