package com.nexus.agent

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Guarda device_id y device_secret cifrados con una clave que Android
 * gestiona en su propio almacén de claves del sistema (Keystore) — el
 * fichero en disco no es legible aunque alguien acceda al almacenamiento
 * del teléfono sin desbloquearlo primero. Mismo principio que el Agent de
 * Windows aplica a sus propios secretos (nunca en texto plano innecesario),
 * adaptado a lo que Android ya trae de fábrica para esto.
 */
class SecureStore(context: Context) {

    private val prefs: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        EncryptedSharedPreferences.create(
            context,
            "nexus_agent_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    var deviceId: String?
        get() = prefs.getString(KEY_DEVICE_ID, null)
        set(value) = prefs.edit().putString(KEY_DEVICE_ID, value).apply()

    var deviceSecret: String?
        get() = prefs.getString(KEY_DEVICE_SECRET, null)
        set(value) = prefs.edit().putString(KEY_DEVICE_SECRET, value).apply()

    fun isPaired(): Boolean = deviceId != null && deviceSecret != null

    fun clear() = prefs.edit().clear().apply()

    private companion object {
        const val KEY_DEVICE_ID = "device_id"
        const val KEY_DEVICE_SECRET = "device_secret"
    }
}
