package com.nexus.agent

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Espejo, en Kotlin, de los endpoints reales de cloud/nexus-cloud/api/ —
 * cada método corresponde a un fichero concreto de ese backend. No
 * reinventa el contrato: usa exactamente los mismos nombres de campo JSON.
 */
class NexusCloudClient(private val baseUrl: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /** api/devices/claim.ts — se llama UNA vez, con el código que el usuario introduce. */
    @Throws(IOException::class)
    fun claim(pairingCode: String, capabilities: List<String>): ClaimResult {
        val body = JSONObject().apply {
            put("pairing_code", pairingCode)
            put("capabilities", JSONArray(capabilities))
        }.toString().toRequestBody(jsonMediaType)

        val request = Request.Builder()
            .url("$baseUrl/api/devices/claim")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("claim falló (${response.code}): $text")
            }
            val json = JSONObject(text)
            return ClaimResult(json.getString("device_id"), json.getString("device_secret"))
        }
    }

    /** api/devices/report.ts — latido periódico. */
    @Throws(IOException::class)
    fun reportHeartbeat(deviceId: String, deviceSecret: String, capabilities: List<String>) {
        val body = JSONObject().apply {
            put("capabilities", JSONArray(capabilities))
        }.toString().toRequestBody(jsonMediaType)

        val request = deviceRequestBuilder(deviceId, deviceSecret)
            .url("$baseUrl/api/devices/report")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("heartbeat falló (${response.code}): ${response.body?.string()}")
            }
        }
    }

    /** api/devices/pending-actions.ts */
    @Throws(IOException::class)
    fun fetchPendingActions(deviceId: String, deviceSecret: String): List<PendingAction> {
        val request = deviceRequestBuilder(deviceId, deviceSecret)
            .url("$baseUrl/api/devices/pending-actions")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("pending-actions falló (${response.code}): $text")
            }
            val actions = JSONObject(text).getJSONArray("actions")
            return (0 until actions.length()).map { i ->
                val a = actions.getJSONObject(i)
                PendingAction(
                    id = a.getString("id"),
                    actionType = a.getString("action_type"),
                    // org.json de Android devuelve la cadena "null" para un null de JSON.
                    target = if (a.isNull("target")) "" else a.getString("target"),
                    params = a.optJSONObject("params") ?: JSONObject(),
                )
            }
        }
    }

    /** api/actions/report.ts */
    @Throws(IOException::class)
    fun reportActionResult(deviceId: String, deviceSecret: String, actionId: String, status: String, result: String?) {
        val body = JSONObject().apply {
            put("action_id", actionId)
            put("status", status)
            if (result != null) put("result", result)
        }.toString().toRequestBody(jsonMediaType)

        val request = deviceRequestBuilder(deviceId, deviceSecret)
            .url("$baseUrl/api/actions/report")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("report de resultado falló (${response.code}): ${response.body?.string()}")
            }
        }
    }

    private fun deviceRequestBuilder(deviceId: String, deviceSecret: String): Request.Builder =
        Request.Builder()
            .addHeader("X-Device-Id", deviceId)
            .addHeader("X-Device-Secret", deviceSecret)

    data class ClaimResult(val deviceId: String, val deviceSecret: String)

    data class PendingAction(
        val id: String,
        val actionType: String,
        val target: String,
        val params: JSONObject,
    )
}
