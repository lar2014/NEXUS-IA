"""Pruebas de nexus_core.cloud_link contra un servidor HTTP REAL en local (imita a Nexus Cloud)
y contra el módulo core.confirm real. Ejecutar:  python -m unittest discover -s tests -v"""
import json
import os
import sys
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import confirm  # noqa: E402
from nexus_core import cloud_link  # noqa: E402
from nexus_core.actions_schema import capabilities_for  # noqa: E402
from nexus_core.cloud_link import CloudError, CloudLink, classify_result, pair  # noqa: E402

SECRET = "SECRET-abc-123"
DEVICE_ID = "dev-1"


class FakeCloud:
    """Estado + servidor HTTP que imita los endpoints reales de cloud/nexus-cloud/api."""

    def __init__(self):
        self.queue, self.reports, self.heartbeats = [], [], []
        self.mode = "ok"            # ok | revoked | instant
        self.fail_polls = 0         # cuántos sondeos devolver como 500
        self.report_fail = 0        # cuántos informes devolver como 500
        self.report_code = None     # forzar un código (p. ej. 404)
        self.poll_count = 0
        self.lock = threading.Lock()
        cloud = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):  # silencio
                pass

            def _send(self, code, obj):
                raw = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def _body(self):
                n = int(self.headers.get("Content-Length") or 0)
                return json.loads(self.rfile.read(n) or b"{}")

            def _authed(self):
                return (self.headers.get("X-Device-Id") == DEVICE_ID and self.headers.get("X-Device-Secret") == SECRET)

            def do_POST(self):
                path = urlparse(self.path).path
                body = self._body()
                if path == "/api/devices/claim":
                    if body.get("pairing_code") == "7F4-K92":
                        return self._send(200, {"device_id": DEVICE_ID, "device_secret": SECRET})
                    return self._send(404, {"error": "código de vinculación inválido"})
                if not self._authed() or cloud.mode == "revoked":
                    return self._send(401, {"error": "dispositivo no autenticado"})
                if path == "/api/devices/report":
                    cloud.heartbeats.append(body)
                    return self._send(200, {"ok": True})
                if path == "/api/actions/report":
                    with cloud.lock:
                        if cloud.report_fail > 0:
                            cloud.report_fail -= 1
                            return self._send(500, {"error": "boom"})
                        if cloud.report_code:
                            return self._send(cloud.report_code, {"error": "ya no admite resultado"})
                        cloud.reports.append((body["action_id"], body["status"], body.get("result", "")))
                    return self._send(200, {"ok": True})
                self._send(404, {"error": "no existe"})

            def do_GET(self):
                if urlparse(self.path).path != "/api/devices/pending-actions":
                    return self._send(404, {"error": "no existe"})
                if not self._authed() or cloud.mode == "revoked":
                    return self._send(401, {"error": "dispositivo no autenticado"})
                with cloud.lock:
                    cloud.poll_count += 1
                    if cloud.fail_polls > 0:
                        cloud.fail_polls -= 1
                        return self._send(500, {"error": "fallo temporal"})
                deadline = time.monotonic() + (0 if cloud.mode == "instant" else 0.3)  # sondeo largo, acortado
                while True:
                    with cloud.lock:
                        if cloud.queue:
                            acts, cloud.queue = cloud.queue, []
                            return self._send(200, {"actions": acts})
                    if time.monotonic() >= deadline:
                        return self._send(200, {"actions": []})
                    time.sleep(0.02)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def push(self, action_id, action_type, target="", params=None):
        with self.lock:
            self.queue.append({"id": action_id, "action_type": action_type, "target": target, "params": params or {}})

    def close(self):
        self.server.shutdown()
        self.server.server_close()


class FakeTools:
    def __init__(self, handlers=None):
        self.calls, self.handlers = [], handlers or {}
        self._has = {"open_app", "web_search", "computer_settings", "file_controller", "browser_control", "send_message"}

    def has(self, name):
        return name in self._has

    def run(self, name, params, ctx=None):
        self.calls.append((name, params, ctx))
        h = self.handlers.get(name)
        return h(params) if callable(h) else (h if h is not None else "Done.")


def wait_for(cond, timeout=5.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


class Base(unittest.TestCase):
    def setUp(self):
        self.cloud = FakeCloud()
        self.tmp = Path(tempfile.mkdtemp())
        self.cfg = self.tmp / "cloud_link.json"
        cloud_link.save_config({"url": self.cloud.url, "device_id": DEVICE_ID, "device_secret": SECRET}, self.cfg)
        self.logs, self.paused, self.links = [], [], []
        confirm.bind(lambda t, d: None, lambda: None)
        confirm._pending = None

    def tearDown(self):
        for l in self.links:
            l.stop()
        time.sleep(0.05)
        self.cloud.close()
        confirm.set_outcome_hook(None)
        confirm._pending = None
        # Ninguna prueba debe haber dejado el secreto en un log
        self.assertFalse([l for l in self.logs if SECRET in l], "el secreto apareció en un log")

    def link(self, tools=None, real_pause=False, **kw):
        def pause(s):
            self.paused.append(s)
            time.sleep(min(s, 0.02))
        l = CloudLink(tools or FakeTools(), ctx_factory=lambda: {"player": "UI"}, log=self.logs.append,
                      config_path=self.cfg, poll_wait_s=1, min_poll_gap_s=kw.pop("min_poll_gap_s", 0.05),
                      pause=None if real_pause else pause, **kw)
        self.links.append(l)
        return l


class TestPairing(Base):
    def test_pair_guarda_credenciales_con_permisos_restringidos(self):
        path = self.tmp / "nuevo.json"
        info = pair("7F4-K92", self.cloud.url, config_path=path)
        self.assertEqual(info["device_id"], DEVICE_ID)
        saved = json.loads(path.read_text())
        self.assertEqual((saved["device_id"], saved["device_secret"]), (DEVICE_ID, SECRET))
        if os.name == "posix":
            self.assertEqual(path.stat().st_mode & 0o077, 0, "el fichero con el secreto no debe ser legible por otros")

    def test_codigo_incorrecto_falla_y_no_escribe_nada(self):
        path = self.tmp / "nada.json"
        with self.assertRaises(CloudError) as ctx:
            pair("XXX-XXX", self.cloud.url, config_path=path)
        self.assertIn("inválido", str(ctx.exception))
        self.assertFalse(path.exists())

    def test_sin_vincular_no_arranca(self):
        l = CloudLink(FakeTools(), config_path=self.tmp / "no-existe.json")
        self.assertFalse(l.is_configured())
        self.assertFalse(l.start())


class TestEjecucion(Base):
    def test_ejecuta_open_app_con_la_traduccion_correcta_y_reporta(self):
        tools = FakeTools()
        l = self.link(tools)
        self.cloud.push("a1", "OPEN_APP", "whatsapp")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(tools.calls[0][:2], ("open_app", {"app_name": "whatsapp"}))
        self.assertEqual(tools.calls[0][2], {"player": "UI"}, "debe recibir el ctx de la interfaz")
        self.assertEqual(self.cloud.reports[0][:2], ("a1", "executed"))

    def test_el_latido_anuncia_capacidades_sin_las_inline(self):
        l = self.link()
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.heartbeats))
        caps = self.cloud.heartbeats[0]["capabilities"]
        self.assertIn("OPEN_APP", caps)
        self.assertNotIn("TAKE_SCREENSHOT", caps, "una capacidad que no se puede ejecutar por remoto no debe anunciarse")

    def test_capabilities_for_conserva_el_comportamiento_anterior_por_defecto(self):
        t = FakeTools()
        self.assertIn("TAKE_SCREENSHOT", capabilities_for(t)["capabilities"])
        self.assertNotIn("TAKE_SCREENSHOT", capabilities_for(t, include_inline=False)["capabilities"])

    def test_accion_sin_tool_se_reporta_como_fallida_sin_ejecutar_nada(self):
        tools = FakeTools()
        l = self.link(tools)
        self.cloud.push("a2", "READ_NOTIFICATION")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(self.cloud.reports[0][:2], ("a2", "failed"))
        self.assertEqual(tools.calls, [])

    def test_captura_de_pantalla_remota_falla_con_motivo_claro(self):
        tools = FakeTools()
        l = self.link(tools)
        self.cloud.push("a3", "TAKE_SCREENSHOT")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(self.cloud.reports[0][1], "failed")
        self.assertIn("sesión de voz", self.cloud.reports[0][2])
        self.assertEqual(tools.calls, [])

    def test_una_tool_que_explota_no_mata_el_enlace(self):
        def boom(_p):
            raise RuntimeError("se cayó")
        tools = FakeTools({"open_app": lambda p: boom(p) if p["app_name"] == "mala" else "Abierta."})
        l = self.link(tools)
        self.cloud.push("b1", "OPEN_APP", "mala")
        self.cloud.push("b2", "OPEN_APP", "buena")
        l.start()
        self.assertTrue(wait_for(lambda: len(self.cloud.reports) == 2))
        got = {r[0]: r[1] for r in self.cloud.reports}
        self.assertEqual(got, {"b1": "failed", "b2": "executed"})

    def test_texto_de_error_de_la_tool_se_clasifica_como_fallo(self):
        tools = FakeTools({"open_app": "Tool 'open_app' failed: no encontrada"})
        l = self.link(tools)
        self.cloud.push("c1", "OPEN_APP", "x")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(self.cloud.reports[0][1], "failed")

    def test_clasificador(self):
        cases = {
            "Abierta.": "executed", "": "executed", None: "executed",
            "[CONFIRMATION_PENDING] I have put a confirmation on screen": "awaiting_device",
            "Tool 'x' failed: boom": "failed", "Tool 'x' is not available.": "failed",
            "'computer_settings' is blocked by the current security policy and will not run.": "failed",
            "I cannot confirm 'x' right now because the interface is not available": "failed",
            "Tool 'x' terminó bien": "executed",
        }
        for text, want in cases.items():
            self.assertEqual(classify_result(text), want, text)


class TestConfirmacionLocal(Base):
    """Usan el core.confirm REAL: lo que se prueba es la integración de verdad."""

    def _gated_tools(self, result="Apagando el equipo."):
        return FakeTools({"computer_settings": lambda p: confirm.request(
            key="computer_settings", title="Apagar", detail=str(p), run=lambda: result)})

    def test_confirmado_en_el_pc_se_reporta_el_desenlace_real(self):
        l = self.link(self._gated_tools())
        self.cloud.push("d1", "SHUTDOWN_DEVICE")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(self.cloud.reports[0][:2], ("d1", "awaiting_device"))
        self.assertNotIn("Say ONE short sentence", self.cloud.reports[0][2], "la instrucción interna para el modelo no es para el usuario")
        self.assertIn("PC", self.cloud.reports[0][2])
        confirm.resolve(True)  # el usuario pulsa CONFIRMAR en el HUD
        self.assertTrue(wait_for(lambda: len(self.cloud.reports) == 2))
        self.assertEqual(self.cloud.reports[1], ("d1", "executed", "Apagando el equipo."))

    def test_cancelado_en_el_pc_se_reporta_como_fallida(self):
        l = self.link(self._gated_tools())
        self.cloud.push("d2", "SHUTDOWN_DEVICE")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        confirm.resolve(False)
        self.assertTrue(wait_for(lambda: len(self.cloud.reports) == 2))
        self.assertEqual(self.cloud.reports[1], ("d2", "failed", "Rechazada en el PC."))

    def test_si_nadie_confirma_caduca_y_se_reporta(self):
        with mock.patch.object(cloud_link, "CONFIRM_TTL_S", 0.3):
            l = self.link(self._gated_tools())
            self.cloud.push("d3", "SHUTDOWN_DEVICE")
            l.start()
            self.assertTrue(wait_for(lambda: len(self.cloud.reports) == 2, timeout=6))
        self.assertEqual(self.cloud.reports[1][:2], ("d3", "failed"))
        self.assertIn("Caducó", self.cloud.reports[1][2])

    def test_una_confirmacion_que_no_venia_de_una_orden_remota_se_ignora(self):
        l = self.link()
        l._on_confirm_outcome("computer_settings", "confirmed", "hecho por voz")
        time.sleep(0.1)
        self.assertEqual(self.cloud.reports, [])

    def test_confirm_sigue_igual_sin_observador_y_un_observador_roto_no_lo_rompe(self):
        ran = []
        confirm.request("k", "t", "d", lambda: ran.append(1) or "ok")
        confirm.resolve(True)
        self.assertTrue(wait_for(lambda: ran))
        confirm.set_outcome_hook(lambda *a: (_ for _ in ()).throw(RuntimeError("observador roto")))
        confirm.request("k", "t", "d", lambda: ran.append(2) or "ok")
        confirm.resolve(True)
        self.assertTrue(wait_for(lambda: ran == [1, 2]), "un observador que falla no debe impedir ejecutar la acción")


class TestResiliencia(Base):
    def test_401_desactiva_el_enlace_y_deja_de_sondear(self):
        self.cloud.mode = "revoked"
        l = self.link()
        l.start()
        self.assertTrue(wait_for(lambda: l.disabled_reason))
        n = self.cloud.poll_count
        time.sleep(0.4)
        self.assertEqual(self.cloud.poll_count, n, "tras un 401 no debe seguir llamando al servidor")
        self.assertTrue(any("rechazó las credenciales" in x for x in self.logs))

    def test_errores_del_servidor_reintentan_con_espera_creciente_y_se_recupera(self):
        self.cloud.fail_polls = 3
        tools = FakeTools()
        l = self.link(tools)
        self.cloud.push("e1", "OPEN_APP", "chrome")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports))
        self.assertEqual(self.paused[:3], [2.0, 4.0, 8.0])
        self.assertEqual(self.cloud.reports[0][:2], ("e1", "executed"))
        self.assertTrue(any("sin conexión" in x for x in self.logs))
        self.assertTrue(any("conectado" in x for x in self.logs))
        self.assertEqual(sum("sin conexión" in x for x in self.logs), 1, "el aviso de caída no debe repetirse en cada reintento")

    def test_respuestas_vacias_instantaneas_no_provocan_un_bucle_frenetico(self):
        self.cloud.mode = "instant"
        l = self.link(real_pause=True, min_poll_gap_s=0.2)
        l.start()
        time.sleep(0.7)
        self.assertLessEqual(self.cloud.poll_count, 6, f"{self.cloud.poll_count} sondeos en 0,7 s: está martilleando al servidor")

    def test_si_informar_falla_reintenta_y_acaba_llegando(self):
        self.cloud.report_fail = 2
        l = self.link()
        self.cloud.push("f1", "OPEN_APP", "x")
        l.start()
        self.assertTrue(wait_for(lambda: self.cloud.reports, timeout=6))
        self.assertEqual(len(self.cloud.reports), 1)
        self.assertIn(1.0, self.paused)
        self.assertIn(2.0, self.paused)

    def test_un_404_al_informar_se_descarta_y_se_registra(self):
        self.cloud.report_code = 404
        l = self.link()
        self.cloud.push("g1", "OPEN_APP", "x")
        l.start()
        self.assertTrue(wait_for(lambda: any("no aceptó el resultado" in x for x in self.logs)))
        self.assertEqual(self.cloud.reports, [])

    def test_el_ctx_se_pide_en_cada_accion(self):
        made = []
        l = self.link()
        l._ctx_factory = lambda: made.append(1) or {"n": len(made)}
        tools = l._tools
        self.cloud.push("h1", "OPEN_APP", "a")
        self.cloud.push("h2", "OPEN_APP", "b")
        l.start()
        self.assertTrue(wait_for(lambda: len(self.cloud.reports) == 2))
        self.assertEqual([c[2]["n"] for c in tools.calls], [1, 2])


class TestCLI(Base):
    def test_pair_status_unpair(self):
        path = self.tmp / "cli.json"
        with mock.patch.object(cloud_link, "_default_config_path", return_value=path):
            self.assertEqual(cloud_link.main(["pair", "7F4-K92", "--url", self.cloud.url]), 0)
            self.assertTrue(path.exists())
            self.assertEqual(cloud_link.main(["status"]), 0)
            self.assertEqual(cloud_link.main(["unpair"]), 0)
            self.assertFalse(path.exists())
            self.assertEqual(cloud_link.main(["status"]), 1)
            self.assertEqual(cloud_link.main(["pair", "MALO", "--url", self.cloud.url]), 1)


if __name__ == "__main__":
    unittest.main()
